/* BLOCKWORLD 2 공통 학습 퀴즈 (IB 학습자상 / 분리수거)
 * 사용법: EduQuiz.show('ib' | 'recycle', { onClose(){...} })
 * 퀴즈가 열려 있는 동안 window.EDUQ_OPEN === true (게임 루프에서 일시정지에 사용)
 * 정답을 맞혀야 닫히며, 같은 문제는 문제은행을 한 바퀴 돌 때까지 다시 나오지 않습니다.
 */
(function () {
  'use strict';

  /* q: 문제, a: 정답, w: 오답 3개, e: 해설 */
  const BANK = {
    ib: [
      { q: '궁금한 것이 생기면 스스로 질문을 만들고 답을 찾아보는 학습자상은?', a: '탐구하는 사람 (Inquirer)', w: ['균형 잡힌 사람 (Balanced)', '배려하는 사람 (Caring)', '원칙을 지키는 사람 (Principled)'], e: '탐구하는 사람은 호기심을 갖고 스스로 질문하며 배움을 즐겨요.' },
      { q: '여러 과목에서 배운 지식을 이해하고 서로 연결하는 학습자상은?', a: '지식이 풍부한 사람 (Knowledgeable)', w: ['소통하는 사람 (Communicator)', '성찰하는 사람 (Reflective)', '위험을 감수하는 사람 (Risk-taker)'], e: '지식이 풍부한 사람은 다양한 분야의 개념을 깊이 이해하고 연결해요.' },
      { q: '근거를 따져 보고 합리적으로 판단하는 학습자상은?', a: '사고하는 사람 (Thinker)', w: ['열린 마음을 가진 사람 (Open-minded)', '균형 잡힌 사람 (Balanced)', '배려하는 사람 (Caring)'], e: '사고하는 사람은 비판적·창의적으로 생각해 문제를 해결해요.' },
      { q: '말, 글, 그림 등 여러 방법으로 생각을 표현하고 친구 말도 잘 듣는 학습자상은?', a: '소통하는 사람 (Communicator)', w: ['탐구하는 사람 (Inquirer)', '원칙을 지키는 사람 (Principled)', '성찰하는 사람 (Reflective)'], e: '소통하는 사람은 자신 있게 표현하고, 다른 사람의 말에 귀 기울여요.' },
      { q: '정직하고 공정하며 자기 행동에 책임지는 학습자상은?', a: '원칙을 지키는 사람 (Principled)', w: ['지식이 풍부한 사람 (Knowledgeable)', '위험을 감수하는 사람 (Risk-taker)', '소통하는 사람 (Communicator)'], e: '원칙을 지키는 사람은 정직하고 공정하게 행동해요.' },
      { q: '나와 다른 문화와 생각을 존중하고 받아들이는 학습자상은?', a: '열린 마음을 가진 사람 (Open-minded)', w: ['사고하는 사람 (Thinker)', '균형 잡힌 사람 (Balanced)', '탐구하는 사람 (Inquirer)'], e: '열린 마음을 가진 사람은 다양한 관점을 존중하고 배우려 해요.' },
      { q: '다른 사람의 마음을 이해하고 도움을 주려는 학습자상은?', a: '배려하는 사람 (Caring)', w: ['원칙을 지키는 사람 (Principled)', '사고하는 사람 (Thinker)', '지식이 풍부한 사람 (Knowledgeable)'], e: '배려하는 사람은 공감하고 다른 사람과 환경을 위해 행동해요.' },
      { q: '실패할까 걱정되어도 용기 내어 새로운 일에 도전하는 학습자상은?', a: '위험을 감수하는 사람 (Risk-taker)', w: ['성찰하는 사람 (Reflective)', '배려하는 사람 (Caring)', '소통하는 사람 (Communicator)'], e: '위험을 감수하는 사람은 불확실한 상황에서도 용기 있게 도전해요.' },
      { q: '공부, 운동, 쉬는 시간처럼 몸과 마음의 조화를 소중히 여기는 학습자상은?', a: '균형 잡힌 사람 (Balanced)', w: ['탐구하는 사람 (Inquirer)', '열린 마음을 가진 사람 (Open-minded)', '사고하는 사람 (Thinker)'], e: '균형 잡힌 사람은 몸과 마음, 여러 활동 사이의 균형을 지켜요.' },
      { q: '내가 잘한 점과 고칠 점을 되돌아보고 더 나아지려는 학습자상은?', a: '성찰하는 사람 (Reflective)', w: ['지식이 풍부한 사람 (Knowledgeable)', '원칙을 지키는 사람 (Principled)', '소통하는 사람 (Communicator)'], e: '성찰하는 사람은 자신의 배움과 경험을 돌아보며 성장해요.' },
      { q: '게임에서 졌지만 "다음엔 이렇게 해 봐야지" 하고 방법을 정리한 지우. 어떤 학습자상일까요?', a: '성찰하는 사람 (Reflective)', w: ['배려하는 사람 (Caring)', '열린 마음을 가진 사람 (Open-minded)', '지식이 풍부한 사람 (Knowledgeable)'], e: '경험을 돌아보고 다음 계획을 세우는 것이 성찰이에요.' },
      { q: '모둠 활동에서 말이 적은 친구에게 "네 생각은 어때?" 하고 물어본 민준. 어떤 학습자상일까요?', a: '배려하는 사람 (Caring)', w: ['위험을 감수하는 사람 (Risk-taker)', '사고하는 사람 (Thinker)', '균형 잡힌 사람 (Balanced)'], e: '친구의 마음을 살피고 참여를 돕는 것이 배려예요.' },
      { q: '아무도 안 봤지만 실수로 깨뜨린 화분을 선생님께 솔직히 말한 서아. 어떤 학습자상일까요?', a: '원칙을 지키는 사람 (Principled)', w: ['소통하는 사람 (Communicator)', '탐구하는 사람 (Inquirer)', '성찰하는 사람 (Reflective)'], e: '정직하게 말하고 책임지는 모습은 원칙을 지키는 사람이에요.' },
      { q: '처음 해 보는 학급 회장 선거에 떨려도 용기 내어 나간 하준. 어떤 학습자상일까요?', a: '위험을 감수하는 사람 (Risk-taker)', w: ['균형 잡힌 사람 (Balanced)', '원칙을 지키는 사람 (Principled)', '지식이 풍부한 사람 (Knowledgeable)'], e: '두려워도 새로운 일에 도전하는 용기가 핵심이에요.' },
      { q: '"왜 플라스틱은 썩지 않을까?" 궁금해서 도서관에서 책을 찾아본 예린. 어떤 학습자상일까요?', a: '탐구하는 사람 (Inquirer)', w: ['배려하는 사람 (Caring)', '소통하는 사람 (Communicator)', '균형 잡힌 사람 (Balanced)'], e: '스스로 궁금증을 갖고 답을 찾아 나서는 것이 탐구예요.' },
      { q: '전학 온 친구 나라의 인사말과 음식을 궁금해하며 배운 도윤. 어떤 학습자상일까요?', a: '열린 마음을 가진 사람 (Open-minded)', w: ['사고하는 사람 (Thinker)', '원칙을 지키는 사람 (Principled)', '위험을 감수하는 사람 (Risk-taker)'], e: '다른 문화를 존중하고 배우려는 마음이 열린 마음이에요.' },
      { q: '게임만 하지 않고 운동, 독서, 잠자는 시간을 골고루 정한 시우. 어떤 학습자상일까요?', a: '균형 잡힌 사람 (Balanced)', w: ['탐구하는 사람 (Inquirer)', '성찰하는 사람 (Reflective)', '배려하는 사람 (Caring)'], e: '생활의 여러 부분을 조화롭게 지키는 것이 균형이에요.' },
      { q: '자기 주장만 하지 않고 자료를 비교한 뒤 더 나은 방법을 고른 유나. 어떤 학습자상일까요?', a: '사고하는 사람 (Thinker)', w: ['소통하는 사람 (Communicator)', '열린 마음을 가진 사람 (Open-minded)', '균형 잡힌 사람 (Balanced)'], e: '근거를 비교해 합리적으로 결정하는 것이 사고하는 사람이에요.' },
      { q: '환경 탐구 결과를 그림과 포스터로 만들어 다른 반에 발표한 지호. 어떤 학습자상일까요?', a: '소통하는 사람 (Communicator)', w: ['원칙을 지키는 사람 (Principled)', '위험을 감수하는 사람 (Risk-taker)', '지식이 풍부한 사람 (Knowledgeable)'], e: '여러 방법으로 생각을 나누는 것이 소통이에요.' },
      { q: '과학 시간에 배운 물의 순환을 사회 시간 기후 이야기와 연결해 설명한 하은. 어떤 학습자상일까요?', a: '지식이 풍부한 사람 (Knowledgeable)', w: ['배려하는 사람 (Caring)', '균형 잡힌 사람 (Balanced)', '성찰하는 사람 (Reflective)'], e: '여러 과목의 지식을 연결해 이해하는 모습이에요.' }
    ],
    recycle: [
      { q: '다 마신 투명 페트병은 어떻게 버릴까요?', a: '내용물을 비우고 라벨을 떼어 찌그러뜨린 뒤 투명 페트병 수거함에', w: ['라벨을 붙인 채 일반쓰레기 봉투에', '뚜껑에 음료를 조금 남겨 플라스틱에', '종이류 수거함에'], e: '투명 페트병은 깨끗하게 비우고 라벨을 떼서 따로 모으면 좋은 재료로 다시 쓰여요.' },
      { q: '택배 상자를 버릴 때 올바른 방법은?', a: '테이프와 송장을 떼고 펼쳐서 종이류로', w: ['테이프째 일반쓰레기로', '물에 적셔서 종이류로', '비닐류 수거함에'], e: '테이프와 송장 스티커는 종이가 아니라서 떼어 내야 해요.' },
      { q: '다 쓴 건전지는 어디에 버릴까요?', a: '폐건전지 전용 수거함', w: ['종량제 봉투', '플라스틱 수거함', '음식물쓰레기'], e: '건전지 속 금속은 환경을 오염시킬 수 있어 전용 수거함에 모아요.' },
      { q: '우유팩은 어떻게 버리는 것이 가장 좋을까요?', a: '씻어서 펼쳐 말린 뒤 종이팩으로 따로', w: ['일반 종이 상자와 함께 묶어서', '우유가 남은 채로 플라스틱에', '일반쓰레기 봉투에'], e: '우유팩(종이팩)은 질 좋은 휴지로 다시 태어날 수 있어 따로 모아요.' },
      { q: '음료 캔은 어떻게 버릴까요?', a: '내용물을 비우고 헹군 뒤 캔류로', w: ['음료가 남은 채로 캔류로', '종이류 수거함에', '일반쓰레기 봉투에'], e: '캔은 비우고 헹구면 여러 번 다시 쓸 수 있는 좋은 자원이에요.' },
      { q: '과자 봉지는 어디로 분리배출할까요?', a: '비닐류 (부스러기를 털어서)', w: ['종이류', '캔류', '유리병류'], e: '과자 봉지는 비닐류예요. 안의 부스러기를 털고 배출해요.' },
      { q: '깨진 유리컵은 어떻게 버릴까요?', a: '신문지 등에 싸서 종량제 봉투에', w: ['유리병 수거함에 그대로', '플라스틱 수거함에', '맨손으로 모아 종이류에'], e: '깨진 유리는 재활용이 어렵고 위험해서 감싸서 종량제 봉투에 버려요.' },
      { q: '다 쓴 형광등은 어디에 버릴까요?', a: '폐형광등 전용 수거함', w: ['유리병 수거함', '종량제 봉투', '플라스틱 수거함'], e: '형광등 속에는 해로운 물질이 있어 전용 수거함에 버려요.' },
      { q: '바나나 껍질은 어디에 버릴까요?', a: '음식물쓰레기', w: ['일반쓰레기', '종이류', '비닐류'], e: '바나나 껍질은 부드러워 음식물쓰레기로 버려요.' },
      { q: '치킨 뼈는 어디에 버릴까요?', a: '일반쓰레기 (종량제 봉투)', w: ['음식물쓰레기', '플라스틱류', '캔류'], e: '닭 뼈처럼 딱딱한 뼈는 동물 먹이로 쓸 수 없어 일반쓰레기예요.' },
      { q: '달걀 껍데기는 어디에 버릴까요?', a: '일반쓰레기 (종량제 봉투)', w: ['음식물쓰레기', '종이류', '플라스틱류'], e: '달걀 껍데기는 딱딱해서 음식물쓰레기가 아니라 일반쓰레기예요.' },
      { q: '마트 영수증은 어디에 버릴까요?', a: '일반쓰레기 (종량제 봉투)', w: ['종이류', '비닐류', '캔류'], e: '영수증은 특수 코팅된 종이(감열지)라 재활용이 안 돼요.' },
      { q: '음식물이 묻은 플라스틱 용기는 어떻게 할까요?', a: '물로 깨끗이 헹군 뒤 플라스틱류로', w: ['묻은 채로 플라스틱류로', '종이류에 넣는다', '음식물쓰레기에 용기째 넣는다'], e: '헹구면 재활용할 수 있어요. 씻어도 지워지지 않으면 일반쓰레기로 버려요.' },
      { q: '유리병을 버릴 때 함께 해야 할 일은?', a: '뚜껑을 따로 분리하고 내용물을 비운다', w: ['뚜껑을 꼭 닫아서 버린다', '병을 깨뜨려서 버린다', '라벨 위에 테이프를 붙인다'], e: '뚜껑은 재질이 달라서 분리하고, 병은 깨지지 않게 버려요.' },
      { q: '깨끗한 스티로폼 상자는 어떻게 버릴까요?', a: '테이프와 스티커를 떼고 스티로폼류로', w: ['잘게 부숴 일반쓰레기로', '종이류 수거함에', '음식물쓰레기에'], e: '깨끗한 흰색 스티로폼은 재활용할 수 있어요.' },
      { q: '기름이 많이 묻은 피자 상자 바닥은 어떻게 할까요?', a: '일반쓰레기 (깨끗한 부분만 종이류로)', w: ['통째로 종이류에', '음식물쓰레기에', '캔류에'], e: '기름에 젖은 종이는 재활용이 어려워요. 깨끗한 뚜껑 부분만 종이류로!' },
      { q: '분리배출의 4가지 약속이 아닌 것은?', a: '최대한 많이 섞어서 버리기', w: ['비운다', '헹군다', '분리한다'], e: '분리배출 약속: 비운다, 헹군다, 분리한다, 섞지 않는다!' },
      { q: '플라스틱 컵에 끼워진 종이 슬리브는?', a: '빼서 종이류로, 컵은 헹궈 플라스틱류로', w: ['컵에 끼운 채 플라스틱류로', '컵째 종이류로', '둘 다 음식물쓰레기로'], e: '재질이 다른 부분은 나누어 버리는 것이 분리배출의 기본이에요.' },
      { q: '양파 껍질은 어디에 버릴까요?', a: '일반쓰레기 (종량제 봉투)', w: ['음식물쓰레기', '비닐류', '종이류'], e: '양파·마늘 껍질처럼 질긴 껍질은 일반쓰레기로 버려요.' },
      { q: '분리배출을 잘하면 좋은 점으로 알맞은 것은?', a: '자원을 다시 쓰고 쓰레기를 줄일 수 있다', w: ['쓰레기가 더 많아진다', '물건이 더 빨리 망가진다', '아무 변화가 없다'], e: '분리배출은 자원 순환의 시작이에요. 지구와 공존하는 방법이죠!' }
    ]
  };

  const THEME = {
    ib: { title: '🧠 IB 학습자상 퀴즈', accent: '#8b5cf6', soft: '#ede9fe', ink: '#2e1065' },
    recycle: { title: '♻️ 분리수거 퀴즈', accent: '#16a34a', soft: '#dcfce7', ink: '#14532d' }
  };

  const queues = { ib: [], recycle: [] };
  let open = false, solved = 0, root = null;
  window.EDUQ_OPEN = false;

  function shuffle(arr) { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; }
  function nextItem(type) { if (!queues[type].length) queues[type] = shuffle(BANK[type].slice()); return queues[type].pop(); }

  function injectStyle() {
    if (document.getElementById('eduq-style')) return;
    const st = document.createElement('style'); st.id = 'eduq-style';
    st.textContent = `
#eduq{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;padding:16px;background:rgba(5,8,20,.72);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);font-family:'Jua','Noto Sans KR',system-ui,sans-serif;animation:eduqIn .25s ease}
#eduq *{box-sizing:border-box}
#eduq .card{width:min(520px,100%);max-height:94vh;overflow:auto;background:#fff;color:var(--ink);border-radius:24px;padding:22px 20px 18px;box-shadow:0 24px 60px rgba(0,0,0,.45);border:4px solid var(--ac);text-align:center}
#eduq .tag{display:inline-block;padding:5px 12px;border-radius:999px;background:var(--soft);color:var(--ac);font-weight:800;font-size:13px}
#eduq h2{margin:10px 0 4px;font-size:clamp(20px,5vw,26px)}
#eduq .q{font-size:clamp(17px,4.4vw,20px);line-height:1.5;margin:14px 2px 16px;word-break:keep-all}
#eduq .opts{display:grid;gap:9px}
#eduq .opt{width:100%;padding:13px 14px;border-radius:14px;border:2px solid var(--soft);background:var(--soft);color:var(--ink);font:inherit;font-size:clamp(15px,4vw,17px);line-height:1.35;cursor:pointer;text-align:left;word-break:keep-all;transition:transform .1s,border-color .1s}
#eduq .opt:hover:not(:disabled){border-color:var(--ac);transform:translateY(-1px)}
#eduq .opt.ok{background:#16a34a;border-color:#16a34a;color:#fff}
#eduq .opt.no{background:#fee2e2;border-color:#ef4444;color:#991b1b;text-decoration:line-through}
#eduq .fb{min-height:24px;margin:12px 0 0;font-size:16px;line-height:1.5;word-break:keep-all}
#eduq .go{display:none;margin:12px auto 0;padding:12px 28px;border:0;border-radius:14px;background:var(--ac);color:#fff;font:inherit;font-size:18px;cursor:pointer}
#eduq .sub{margin-top:10px;font-size:12px;opacity:.6}
@keyframes eduqIn{from{opacity:0}to{opacity:1}}
@keyframes eduqShake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}`;
    document.head.appendChild(st);
  }

  function close(cb) {
    if (root) { root.remove(); root = null; }
    open = false; window.EDUQ_OPEN = false;
    try { cb && cb(); } catch (e) { console.error(e); }
  }

  function show(type, opts) {
    opts = opts || {};
    if (open || !BANK[type]) return false;
    injectStyle();
    open = true; window.EDUQ_OPEN = true;
    try { opts.onOpen && opts.onOpen(); } catch (e) { console.error(e); }
    if (document.exitPointerLock && document.pointerLockElement) document.exitPointerLock();

    const th = THEME[type], item = nextItem(type);
    const choices = shuffle([item.a].concat(item.w));
    root = document.createElement('div'); root.id = 'eduq';
    root.style.setProperty('--ac', th.accent); root.style.setProperty('--soft', th.soft); root.style.setProperty('--ink', th.ink);
    root.innerHTML = `<div class="card" role="dialog" aria-modal="true"><span class="tag"></span><h2></h2><p class="q"></p><div class="opts"></div><p class="fb"></p><button class="go">계속하기 ▶</button><div class="sub">정답을 맞히면 게임이 이어져요</div></div>`;
    root.querySelector('.tag').textContent = opts.label || '학습 구간';
    root.querySelector('h2').textContent = th.title;
    root.querySelector('.q').textContent = item.q;
    const box = root.querySelector('.opts'), fb = root.querySelector('.fb'), go = root.querySelector('.go'), card = root.querySelector('.card');
    let tries = 0;
    choices.forEach(function (text) {
      const b = document.createElement('button'); b.className = 'opt'; b.type = 'button'; b.textContent = text;
      b.addEventListener('click', function (ev) {
        ev.stopPropagation();
        if (text === item.a) {
          b.classList.add('ok'); box.querySelectorAll('.opt').forEach(function (x) { x.disabled = true; });
          solved++;
          fb.textContent = (tries === 0 ? '정답! 🎉 ' : '정답이에요! 👏 ') + item.e;
          root.querySelector('.sub').textContent = '지금까지 맞힌 퀴즈: ' + solved + '개';
          go.style.display = 'block'; go.focus();
        } else {
          tries++; b.classList.add('no'); b.disabled = true;
          fb.textContent = '아쉬워요! 다시 한 번 생각해 보세요 🤔';
          card.style.animation = 'none'; void card.offsetWidth; card.style.animation = 'eduqShake .3s';
        }
      });
      box.appendChild(b);
    });
    go.addEventListener('click', function (ev) { ev.stopPropagation(); close(opts.onClose); });
    /* 게임 쪽 키 입력이 퀴즈 중에 동작하지 않도록 차단 (Enter는 계속하기) */
    root.addEventListener('keydown', function (ev) { ev.stopPropagation(); if (ev.key === 'Enter' && go.style.display === 'block') close(opts.onClose); });
    ['pointerdown', 'mousedown', 'touchstart', 'wheel'].forEach(function (n) { root.addEventListener(n, function (ev) { ev.stopPropagation(); }); });
    document.body.appendChild(root);
    return true;
  }

  window.EduQuiz = { show: show, isOpen: function () { return open; }, solved: function () { return solved; } };
})();
