# 블록월드 2 - 게임 선택형 플랫폼

사용자가 제공한 `index.html` 내부의 Base64 게임 소스 4개를 추출해 각각 독립 HTML로 분리하고, 게임 선택 화면에서 실행하도록 구성했습니다.

## 추출된 게임
- `speed.html` — +1 스피드 키보드 탈출 3D
- `egg.html` — 계란 서리단
- `rivals.html` — RIVALS 3D
- `blockblast.html` — 블록 블라스트

## GitHub 업로드
압축을 해제한 뒤 프로젝트 최상위의 `package.json`, `index.html`, `server.js`, `src/`, `public/games/`를 GitHub 저장소에 업로드합니다.

## Render 설정
일반 업로드 방식:
- Build Command: `npm install && npm run build`
- Start Command: `npm start`

ZIP 자체를 저장소에 올리는 방식(파일명 `blockworld2-platform-login.zip`):
- Build Command: `unzip -o blockworld2-platform-login.zip -d app && cd app && npm install && npm run build`
- Start Command: `cd app && npm start`

## Render 환경변수
- `VITE_SUPABASE_URL`: Supabase Project URL
- `VITE_SUPABASE_ANON_KEY`: Publishable key 또는 legacy anon public key

Supabase의 Realtime 기능을 활성화하세요. 이 버전은 Realtime Broadcast/Presence를 사용하므로 별도 SQL 테이블은 필요하지 않습니다. service_role 또는 secret 키는 절대 사용하지 마세요.

## 온라인 기능과 제한
Supabase로 같은 월드 코드에 접속한 사용자들의 온라인 상태와 채팅, 누가 어떤 게임을 실행했는지 알림을 공유합니다.
중요: 추출한 네 게임의 원본 코드는 각각 독립 게임입니다. 따라서 게임 내부의 캐릭터·점수·맵 진행 상태가 서로 동기화되는 실시간 협동/대전 멀티플레이는 아직 구현되지 않았습니다. 각 게임별 네트워크 동기화 코드를 별도로 추가해야 합니다.

## 실행
같은 사이트에 접속한 뒤 동일한 월드 코드를 입력합니다. 게임 목록에서 카드를 누르면 해당 게임이 실행되고, `게임 목록` 버튼으로 돌아옵니다.


## 멀티플레이 캐릭터 동기화
- 같은 월드 코드에 접속한 뒤 **같은 게임**을 실행하면 3D 게임 화면에서 서로의 캐릭터를 볼 수 있습니다.
- `speed`, `egg`, `rivals` 게임에서 위치와 방향을 Supabase Realtime Broadcast로 동기화합니다.
- `blockblast`는 퍼즐 게임이라 3D 캐릭터가 없습니다.
- 게임 내 점수, 아이템, 총알 판정, 맵 진행도까지 공유하는 완전한 협동/대전 동기화는 별도 구현이 필요합니다.
- 이 업데이트도 기존과 동일하게 Supabase URL 및 Publishable/anon public key 환경변수를 사용하며, 추가 SQL은 필요하지 않습니다.


## 계정 로그인·저장 및 스피드 게임 관리자 기능
1. Supabase SQL Editor에서 `supabase/setup.sql` 전체를 실행합니다.
2. 사이트에서 관리자 계정을 먼저 회원가입합니다. Supabase Authentication > Users에서 해당 계정의 UUID를 복사합니다.
3. SQL Editor에서 `insert into public.speed_game_admins(user_id) values ('여기에-관리자-UUID');`를 실행합니다. 관리자 등록은 한 번만 합니다.
4. 학생은 각자 이메일/비밀번호로 계정을 만들고 로그인한 뒤 월드에 입장합니다. 스피드 게임의 스피드·코인·승리·환생·아이템 등 저장 데이터는 계정에 연결되어 기기를 바꾸어도 불러옵니다.
5. 관리자 계정으로 로그인하고 스피드 게임의 Admin 패널을 열어 기존 비밀번호 잠금을 해제하면 전체 서버 어뷰즈와 접속 플레이어별 스탯 초기화 도구가 표시됩니다.

주의: Supabase Authentication에서 이메일 확인이 켜져 있으면 회원가입 후 메일 인증을 해야 로그인할 수 있습니다. 테스트용 학급 환경에서는 Authentication 설정의 이메일 확인 정책을 확인하세요. `service_role` 키는 Render 환경변수나 브라우저에 넣지 마세요.

## 플랫폼 공통 로그인 및 게임별 저장 확장
- 로그인은 개별 게임 내부가 아니라 BLOCKWORLD 2 플랫폼에서 한 번만 합니다. 로그인 세션은 Supabase Auth에 유지되며 게임을 바꾸어도 같은 계정이 사용됩니다.
- `speed` 저장은 `speed_game_saves`, `egg`와 `blockblast` 저장은 `platform_game_saves`에 계정별로 저장됩니다.
- `rivals`는 현재 라운드형 게임으로 영구 진행 데이터(레벨/인벤토리 등)가 없어 계정별 진행 저장 대상은 아닙니다.
- 기존 Supabase 사용자는 `supabase/setup.sql`의 추가된 `platform_game_saves` 부분도 SQL Editor에서 실행해야 합니다. 이미 앞부분을 실행했다면 파일의 마지막 플랫폼 저장 SQL 블록만 실행해도 됩니다.


## 학생 27명 사전 계정 생성
- 로그인 화면은 이메일 대신 아래 학생 ID를 입력하도록 변경되었습니다.
- 모든 계정의 초기 비밀번호는 `44class`입니다.
- 계정 이메일은 내부 로그인용으로 `bw2student01@blockworld2.invalid`부터 `bw2student27@blockworld2.invalid`까지 자동 매핑됩니다. 학생은 내부 이메일을 입력하지 않습니다.
- Render 환경변수에 `SUPABASE_SERVICE_ROLE_KEY`와 `CLASS_ACCOUNT_SETUP_SECRET`을 추가하세요. `SUPABASE_SERVICE_ROLE_KEY`는 Supabase의 service_role/secret 키이며 서버에서만 사용합니다. `VITE_` 접두사를 붙이지 마세요. `CLASS_ACCOUNT_SETUP_SECRET`에는 충분히 긴 임의 문자열을 지정하세요.
- Render 재배포 후 로그인 화면에서 `학생 계정 일괄 준비`를 누르고 `CLASS_ACCOUNT_SETUP_SECRET` 값을 입력하면 27개 계정이 생성됩니다. 이미 있는 계정은 비밀번호를 `44class`로 재설정하고 표시 이름을 갱신합니다.
- 학생 로그인은 학생 ID와 `44class`를 사용합니다. 회원가입 이메일 인증은 사용하지 않습니다.
- 일괄 생성이 끝나면 보안을 위해 Render에서 `CLASS_ACCOUNT_SETUP_SECRET` 값을 변경하거나 삭제하고 다시 배포하세요. `SUPABASE_SERVICE_ROLE_KEY`는 계속 서버 환경변수에만 보관하세요.
- 주의: 공통 비밀번호는 계정 간 구분이 약합니다. 학생들이 서로의 ID를 알고 있으면 다른 학생 계정에도 로그인할 수 있습니다. 실제 운영에서는 개인별 비밀번호로 변경하는 것을 권장합니다.
