import { createClient } from '@supabase/supabase-js';
import './style.css';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
const $ = id => document.getElementById(id);
const TITLES = {
  speed: '+1 스피드 키보드 탈출 3D',
  egg: '계란 서리단',
  rivals: 'RIVALS 3D',
  blockblast: '블록 블라스트'
};
let supabase=null, channel=null, playerId=crypto.randomUUID(), playerName='플레이어', room='CLASS4', currentGame='';
let chatCooldown=0, toastTimer=null, lastPositionSent=0;

function toast(message){$('toast').textContent=message;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),2200);}
function addChat(name,message){
  const line=document.createElement('div');line.className='chat-line';
  const b=document.createElement('b');b.textContent=name+': ';
  line.append(b,document.createTextNode(message));
  $('chat-messages').append(line);$('chat-messages').scrollTop=$('chat-messages').scrollHeight;
  while($('chat-messages').children.length>50)$('chat-messages').firstChild.remove();
}
function updateCount(){
  if(!channel)return;
  const state=channel.presenceState();let count=0;
  Object.values(state).forEach(list=>count+=list.length);
  $('online-count').textContent=count+'명 온라인';$('game-online').textContent='온라인 '+count+'명';
}
async function joinRoom(){
  if(!SUPABASE_URL||!SUPABASE_KEY){
    $('room-error').textContent='Render 환경변수 VITE_SUPABASE_URL 및 VITE_SUPABASE_ANON_KEY를 설정해야 합니다.';
    return false;
  }
  try{
    supabase=createClient(SUPABASE_URL,SUPABASE_KEY);
    channel=supabase.channel('blockworld2-lobby-'+room,{config:{broadcast:{self:false},presence:{key:playerId}}});
    channel.on('presence',{event:'sync'},updateCount);
    channel.on('presence',{event:'join'},updateCount);
    channel.on('presence',{event:'leave'},updateCount);
    channel.on('broadcast',{event:'chat'},({payload})=>addChat(payload.name,payload.message));
    channel.on('broadcast',{event:'game'},({payload})=>{
      if(payload.id!==playerId) toast(payload.name+' 님이 '+(TITLES[payload.game]||'게임')+' 플레이를 시작했습니다.');
    });
    channel.on('broadcast',{event:'admin-abuse'},({payload})=>{
      if(!payload || payload.sourceId===playerId) return;
      const frame=$('game-frame');
      if(frame.contentWindow && currentGame==='speed'){
        frame.contentWindow.postMessage({type:'bw2:admin-abuse',state:payload.state},'*');
      }
    });
    channel.on('broadcast',{event:'position'},({payload})=>{
      if(!payload||payload.id===playerId||payload.game!==currentGame)return;
      const frame=$('game-frame');
      if(frame.contentWindow)frame.contentWindow.postMessage({type:'bw2:remote',player:payload},'*');
    });
    await new Promise((resolve,reject)=>{
      let finished=false;
      const timer=setTimeout(()=>{if(!finished){finished=true;reject(new Error('연결 시간 초과'));}},12000);
      channel.subscribe(async status=>{
        if(status==='SUBSCRIBED'&&!finished){
          finished=true;clearTimeout(timer);
          await channel.track({id:playerId,name:playerName,game:''});
          $('online-status').textContent='실시간 연결됨';$('online-status').classList.add('online');
          resolve();
        }else if((status==='CHANNEL_ERROR'||status==='TIMED_OUT')&&!finished){
          finished=true;clearTimeout(timer);reject(new Error('Supabase Realtime 연결 실패'));
        }
      });
    });
    return true;
  }catch(e){
    $('room-error').textContent=e.message;
    $('online-status').textContent='연결 오류';
    return false;
  }
}
async function sendChat(message){
  const clean=message.trim().slice(0,100);
  if(!clean||!channel||Date.now()-chatCooldown<500)return;
  chatCooldown=Date.now();
  const payload={name:playerName,message:clean};
  addChat(payload.name,payload.message);
  await channel.send({type:'broadcast',event:'chat',payload});
}
async function launchGame(key){
  if(!TITLES[key])return;
  currentGame=key;
  $('active-game-title').textContent=TITLES[key];
  $('launcher').classList.add('hidden');$('game-view').classList.remove('hidden');
  $('game-frame').src='/games/'+key+'.html';
  $('chat-messages').replaceChildren();
  if(channel){
    await channel.track({id:playerId,name:playerName,game:key});
    await channel.send({type:'broadcast',event:'game',payload:{id:playerId,name:playerName,game:key}});
  }
  toast(TITLES[key]+' 시작');
}
async function backToGames(){
  $('game-frame').src='about:blank';
  $('game-view').classList.add('hidden');$('launcher').classList.remove('hidden');
  currentGame='';
  if(channel)await channel.track({id:playerId,name:playerName,game:''});
}
$('room-form').addEventListener('submit',async e=>{
  e.preventDefault();
  playerName=$('player-name').value.trim().slice(0,16)||'플레이어';
  room=$('room-code').value.trim().toUpperCase().replace(/[^A-Z0-9_-]/g,'').slice(0,16)||'CLASS4';
  $('room-error').textContent='';
  const btn=$('room-form').querySelector('button[type="submit"]');btn.disabled=true;btn.textContent='연결 중...';
  const ok=await joinRoom();
  btn.disabled=false;btn.textContent='입장하기';
  if(!ok)return;
  $('player-label').textContent=playerName;$('room-name').textContent=room;
  $('room-modal').classList.remove('show');
  toast(room+' 월드에 접속했습니다.');
});
$('change-room').addEventListener('click',async()=>{
  if(channel){await supabase.removeChannel(channel);channel=null;}
  $('room-modal').classList.add('show');$('room-error').textContent='';
});
document.querySelectorAll('[data-game]').forEach(btn=>btn.addEventListener('click',()=>launchGame(btn.dataset.game)));
$('back-games').addEventListener('click',backToGames);
$('chat-form').addEventListener('submit',e=>{e.preventDefault();sendChat($('chat-input').value);$('chat-input').value='';});
$('chat-toggle').addEventListener('click',()=>{
  const panel=$('chat-toggle').closest('.game-chat');panel.classList.toggle('collapsed');
  $('chat-toggle').textContent=panel.classList.contains('collapsed')?'+':'−';
});
window.addEventListener('message',async e=>{
  if(e.source!==$('game-frame').contentWindow || !e.data || e.data.type!=='bw2:admin-abuse' || !channel) return;
  const state=e.data.state;
  if(!state || typeof state!=='object') return;
  await channel.send({type:'broadcast',event:'admin-abuse',payload:{sourceId:playerId,state}});
});
window.addEventListener('message',async e=>{
  if(e.source!==$('game-frame').contentWindow||!e.data||e.data.type!=='bw2:position'||!channel||!currentGame)return;
  const now=Date.now();if(now-lastPositionSent<180)return;lastPositionSent=now;
  const d=e.data;
  const payload={id:playerId,name:playerName,game:currentGame,x:Number(d.x)||0,y:Number(d.y)||0,z:Number(d.z)||0,rotation:Number(d.rotation)||0};
  await channel.send({type:'broadcast',event:'position',payload});
});
window.addEventListener('beforeunload',()=>{if(channel)supabase.removeChannel(channel);});
$('room-modal').classList.add('show');
$('player-name').focus();
