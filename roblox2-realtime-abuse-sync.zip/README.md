# 블록월드 2 - 게임 선택형 플랫폼

사용자가 제공한 `index.html` 내부의 Base64 게임 소스 4개를 추출해 각각 독립 HTML로 분리하고, 게임 선택 화면에서 실행하도록 구성했습니다.

## 추출된 게임
- `speed.html` — +1 스피드 키보드 탈출 3D
- `egg.html` — 계란 서리단
- `rivals.html` — RIVALS 3D
- `blockblast.html` — 블록 블라스트

## GitHub 업로드
압축을 해제한 뒤 프로젝트 최상위의 `package.json`, `index.html`, `server.js`, `src/`, `public/games/`를 GitHub 저장소에 업로드합니다.

## Render 설정
일반 업로드 방식:
- Build Command: `npm install && npm run build`
- Start Command: `npm start`

ZIP 자체를 저장소에 올리는 방식(파일명 `roblox2-multiplayer.zip`):
- Build Command: `unzip -o roblox2-multiplayer.zip -d app && cd app && npm install && npm run build`
- Start Command: `cd app && npm start`

## Render 환경변수
- `VITE_SUPABASE_URL`: Supabase Project URL
- `VITE_SUPABASE_ANON_KEY`: Publishable key 또는 legacy anon public key

Supabase의 Realtime 기능을 활성화하세요. 이 버전은 Realtime Broadcast/Presence를 사용하므로 별도 SQL 테이블은 필요하지 않습니다. service_role 또는 secret 키는 절대 사용하지 마세요.

## 온라인 기능과 제한
Supabase로 같은 월드 코드에 접속한 사용자들의 온라인 상태와 채팅, 누가 어떤 게임을 실행했는지 알림을 공유합니다.
중요: 추출한 네 게임의 원본 코드는 각각 독립 게임입니다. 따라서 게임 내부의 캐릭터·점수·맵 진행 상태가 서로 동기화되는 실시간 협동/대전 멀티플레이는 아직 구현되지 않았습니다. 각 게임별 네트워크 동기화 코드를 별도로 추가해야 합니다.

## 실행
같은 사이트에 접속한 뒤 동일한 월드 코드를 입력합니다. 게임 목록에서 카드를 누르면 해당 게임이 실행되고, `게임 목록` 버튼으로 돌아옵니다.


## 멀티플레이 캐릭터 동기화
- 같은 월드 코드에 접속한 뒤 **같은 게임**을 실행하면 3D 게임 화면에서 서로의 캐릭터를 볼 수 있습니다.
- `speed`, `egg`, `rivals` 게임에서 위치와 방향을 Supabase Realtime Broadcast로 동기화합니다.
- `blockblast`는 퍼즐 게임이라 3D 캐릭터가 없습니다.
- 게임 내 점수, 아이템, 총알 판정, 맵 진행도까지 공유하는 완전한 협동/대전 동기화는 별도 구현이 필요합니다.
- 이 업데이트도 기존과 동일하게 Supabase URL 및 Publishable/anon public key 환경변수를 사용하며, 추가 SQL은 필요하지 않습니다.


## 실시간 어드민 어뷰즈 동기화 업데이트
- 같은 월드의 스피드 게임 플레이어에게 어뷰즈 시작/종료와 걸음·승수 배수, 지속 시간을 Supabase Realtime Broadcast로 전달합니다.
- 배수 설정은 입력이 멈춘 뒤 한 번만 전송하도록 디바운스 처리했습니다. 게임 프레임마다 전송하지 않습니다.
- 플레이어 위치 브로드캐스트 빈도를 초당 약 10회에서 약 5회로 낮춰 통신량을 줄였습니다.
- 이 버전은 업로드된 `roblox2-multiplayer-characters.zip` 기반 패치입니다. 기존 계정/관리자 인증 체계는 포함하지 않으며, 게임 내부 비밀번호 방식은 보안 인증을 대체하지 않습니다.
