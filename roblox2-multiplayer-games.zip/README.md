# 블록월드 2 - 게임 선택형 플랫폼

사용자가 제공한 `index.html` 내부의 Base64 게임 소스 4개를 추출해 각각 독립 HTML로 분리하고, 게임 선택 화면에서 실행하도록 구성했습니다.

## 추출된 게임
- `speed.html` — +1 스피드 키보드 탈출 3D
- `egg.html` — 계란 서리단
- `rivals.html` — RIVALS 3D
- `blockblast.html` — 블록 블라스트

## GitHub 업로드
압축을 해제한 뒤 프로젝트 최상위의 `package.json`, `index.html`, `server.js`, `src/`, `public/games/`를 GitHub 저장소에 업로드합니다.

## Render 설정
일반 업로드 방식:
- Build Command: `npm install && npm run build`
- Start Command: `npm start`

ZIP 자체를 저장소에 올리는 방식(파일명 `roblox2-multiplayer.zip`):
- Build Command: `unzip -o roblox2-multiplayer.zip -d app && cd app && npm install && npm run build`
- Start Command: `cd app && npm start`

## Render 환경변수
- `VITE_SUPABASE_URL`: Supabase Project URL
- `VITE_SUPABASE_ANON_KEY`: Publishable key 또는 legacy anon public key

Supabase의 Realtime 기능을 활성화하세요. 이 버전은 Realtime Broadcast/Presence를 사용하므로 별도 SQL 테이블은 필요하지 않습니다. service_role 또는 secret 키는 절대 사용하지 마세요.

## 온라인 기능과 제한
Supabase로 같은 월드 코드에 접속한 사용자들의 온라인 상태와 채팅, 누가 어떤 게임을 실행했는지 알림을 공유합니다.
중요: 추출한 네 게임의 원본 코드는 각각 독립 게임입니다. 따라서 게임 내부의 캐릭터·점수·맵 진행 상태가 서로 동기화되는 실시간 협동/대전 멀티플레이는 아직 구현되지 않았습니다. 각 게임별 네트워크 동기화 코드를 별도로 추가해야 합니다.

## 실행
같은 사이트에 접속한 뒤 동일한 월드 코드를 입력합니다. 게임 목록에서 카드를 누르면 해당 게임이 실행되고, `게임 목록` 버튼으로 돌아옵니다.
