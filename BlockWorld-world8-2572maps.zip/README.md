# 블록월드 2 - 게임 선택형 플랫폼

사용자가 제공한 `index.html` 내부의 Base64 게임 소스 4개를 추출해 각각 독립 HTML로 분리하고, 게임 선택 화면에서 실행하도록 구성했습니다.

## 추출된 게임
- `speed.html` — +1 스피드 키보드 탈출 3D
- `egg.html` — 계란 서리단
- `rivals.html` — RIVALS 3D
- `blockblast.html` — 블록 블라스트

## GitHub 업로드
압축을 해제한 뒤 프로젝트 최상위의 `package.json`, `index.html`, `server.js`, `src/`, `public/games/`를 GitHub 저장소에 업로드합니다.

## Render 설정
일반 업로드 방식:
- Build Command: `npm install && npm run build`
- Start Command: `npm start`

ZIP 자체를 저장소에 올리는 방식(파일명 `blockworld2-platform-login.zip`):
- Build Command: `unzip -o blockworld2-platform-login.zip -d app && cd app && npm install && npm run build`
- Start Command: `cd app && npm start`

## Render 환경변수
- `VITE_SUPABASE_URL`: Supabase Project URL
- `VITE_SUPABASE_ANON_KEY`: Publishable key 또는 legacy anon public key

Supabase의 Realtime 기능을 활성화하세요. 이 버전은 Realtime Broadcast/Presence를 사용하므로 별도 SQL 테이블은 필요하지 않습니다. service_role 또는 secret 키는 절대 사용하지 마세요.

## 온라인 기능과 제한
Supabase로 같은 월드 코드에 접속한 사용자들의 온라인 상태와 채팅, 누가 어떤 게임을 실행했는지 알림을 공유합니다.
중요: 추출한 네 게임의 원본 코드는 각각 독립 게임입니다. 따라서 게임 내부의 캐릭터·점수·맵 진행 상태가 서로 동기화되는 실시간 협동/대전 멀티플레이는 아직 구현되지 않았습니다. 각 게임별 네트워크 동기화 코드를 별도로 추가해야 합니다.

## 실행
같은 사이트에 접속한 뒤 동일한 월드 코드를 입력합니다. 게임 목록에서 카드를 누르면 해당 게임이 실행되고, `게임 목록` 버튼으로 돌아옵니다.


## 멀티플레이 캐릭터 동기화
- 같은 월드 코드에 접속한 뒤 **같은 게임**을 실행하면 3D 게임 화면에서 서로의 캐릭터를 볼 수 있습니다.
- `speed`, `egg`, `rivals` 게임에서 위치와 방향을 Supabase Realtime Broadcast로 동기화합니다.
- `blockblast`는 퍼즐 게임이라 3D 캐릭터가 없습니다.
- 게임 내 점수, 아이템, 총알 판정, 맵 진행도까지 공유하는 완전한 협동/대전 동기화는 별도 구현이 필요합니다.
- 이 업데이트도 기존과 동일하게 Supabase URL 및 Publishable/anon public key 환경변수를 사용하며, 추가 SQL은 필요하지 않습니다.


## 계정 로그인·저장 및 스피드 게임 관리자 기능
1. Supabase SQL Editor에서 `supabase/setup.sql` 전체를 실행합니다.
2. 사이트에서 관리자 계정을 먼저 회원가입합니다. Supabase Authentication > Users에서 해당 계정의 UUID를 복사합니다.
3. SQL Editor에서 `insert into public.speed_game_admins(user_id) values ('여기에-관리자-UUID');`를 실행합니다. 관리자 등록은 한 번만 합니다.
4. 학생은 각자 이메일/비밀번호로 계정을 만들고 로그인한 뒤 월드에 입장합니다. 스피드 게임의 스피드·코인·승리·환생·아이템 등 저장 데이터는 계정에 연결되어 기기를 바꾸어도 불러옵니다.
5. 관리자 계정으로 로그인하고 스피드 게임의 Admin 패널을 열어 기존 비밀번호 잠금을 해제하면 전체 서버 어뷰즈와 접속 플레이어별 스탯 초기화 도구가 표시됩니다.

주의: Supabase Authentication에서 이메일 확인이 켜져 있으면 회원가입 후 메일 인증을 해야 로그인할 수 있습니다. 테스트용 학급 환경에서는 Authentication 설정의 이메일 확인 정책을 확인하세요. `service_role` 키는 Render 환경변수나 브라우저에 넣지 마세요.

## 플랫폼 공통 로그인 및 게임별 저장 확장
- 로그인은 개별 게임 내부가 아니라 BLOCKWORLD 2 플랫폼에서 한 번만 합니다. 로그인 세션은 Supabase Auth에 유지되며 게임을 바꾸어도 같은 계정이 사용됩니다.
- `speed` 저장은 `speed_game_saves`, `egg`와 `blockblast` 저장은 `platform_game_saves`에 계정별로 저장됩니다.
- `rivals`는 현재 라운드형 게임으로 영구 진행 데이터(레벨/인벤토리 등)가 없어 계정별 진행 저장 대상은 아닙니다.
- 기존 Supabase 사용자는 `supabase/setup.sql`의 추가된 `platform_game_saves` 부분도 SQL Editor에서 실행해야 합니다. 이미 앞부분을 실행했다면 파일의 마지막 플랫폼 저장 SQL 블록만 실행해도 됩니다.


## 학생 27명 사전 계정 생성
- 로그인 화면은 이메일 대신 아래 학생 ID를 입력하도록 변경되었습니다.
- 모든 계정의 초기 비밀번호는 `44class`입니다.
- 계정 이메일은 내부 로그인용으로 `bw2student01@blockworld2.invalid`부터 `bw2student27@blockworld2.invalid`까지 자동 매핑됩니다. 학생은 내부 이메일을 입력하지 않습니다.
- Render 환경변수에 `SUPABASE_SERVICE_ROLE_KEY`와 `CLASS_ACCOUNT_SETUP_SECRET`을 추가하세요. `SUPABASE_SERVICE_ROLE_KEY`는 Supabase의 service_role/secret 키이며 서버에서만 사용합니다. `VITE_` 접두사를 붙이지 마세요. `CLASS_ACCOUNT_SETUP_SECRET`에는 충분히 긴 임의 문자열을 지정하세요.
- Render 재배포 후 로그인 화면에서 `학생 계정 일괄 준비`를 누르고 `CLASS_ACCOUNT_SETUP_SECRET` 값을 입력하면 27개 계정이 생성됩니다. 이미 있는 계정은 비밀번호를 `44class`로 재설정하고 표시 이름을 갱신합니다.
- 학생 로그인은 학생 ID와 `44class`를 사용합니다. 회원가입 이메일 인증은 사용하지 않습니다.
- 일괄 생성이 끝나면 보안을 위해 Render에서 `CLASS_ACCOUNT_SETUP_SECRET` 값을 변경하거나 삭제하고 다시 배포하세요. `SUPABASE_SERVICE_ROLE_KEY`는 계속 서버 환경변수에만 보관하세요.
- 주의: 공통 비밀번호는 계정 간 구분이 약합니다. 학생들이 서로의 ID를 알고 있으면 다른 학생 계정에도 로그인할 수 있습니다. 실제 운영에서는 개인별 비밀번호로 변경하는 것을 권장합니다.

## 추가된 모바일 3D 게임
- `doors.html` — DOORS 스타일 복도 탐험, 열쇠 수집 및 괴물 회피
- `bedwars.html` — BedWars 스타일 자원 수집 및 상대 침대 공략
- `garden.html` — Grow a Garden 스타일 씨앗 심기·물주기·수확
- `brainrot.html` — Steal a Brainrot 스타일 수집품 운반
- `forest99.html` — 사용자가 제공한 99밤 숲속 생존 3D 게임
- 다섯 게임 모두 왼쪽 가상 조이스틱 이동, 오른쪽 드래그 시점 회전, 행동/점프 버튼을 지원합니다.
- 기존 4개 게임은 그대로 유지했습니다. 새 게임들은 원작의 공식 에셋이 아닌 독립적인 간단한 3D 미니게임 구현입니다.

### 3D game polish update
- The five added games now use improved 3D rendering, higher-quality lighting, soft shadows, richer scene dressing and more detailed player presentation.
- DOORS: hotel corridor trim, ceiling details, wall lights and furniture.
- BedWars: floating-island cliffs, team structures, bed models and bridge details.
- Grow a Garden: farm fencing, orchard trees, greenhouse and decorative flower beds.
- Steal a Brainrot: neon collector plaza, vault, display plinths and luminous accents.
- 99 Nights in the Forest: improved tone mapping, shadowing and mobile rendering budget.
- These are original, simplified recreations inspired by the named game concepts; they do not reproduce proprietary original maps, models, sounds or complete online systems.

### 업그레이드 v3 (DOORS / Grow a Garden / Steal a Brainrot)
- `bwcore.js`에 코인·상점·저장 API 추가, 각 게임은 `doors-x.js`, `garden-x.js`, `brainrot-x.js`가 확장합니다.
- 상점 강화·코인·레벨은 계정별로 저장됩니다 (`supabase/setup.sql` 마지막 블록 실행 필요).

## +1 스피드 키보드 탈출 — 맵 구조 / 장애물 다양성 / 밸런스 패치
`public/games/speed.html`의 스테이지 생성기(`build`)를 다시 만들었습니다. 저장 데이터 형식은 그대로라 기존 진행도·기록이 유지됩니다.

### 맵 구조
- 스테이지 = **구간(점프 / 회피 / 타이밍 테마)** 반복 + 구간 끝 **휴식 발판(📍체크포인트)**. 구간 시작·끝에 표지판, HUD에 `구간 n/N · ⏱현재/목표` 표시.
- **월드별 장애물 풀**: 캔디(기본기) → 초콜릿(컨베이어·통나무·프레스) → 해커(레이저·슬라이더·슬라롬) → 백룸(전부 + 복합 코스). 스테이지가 올라갈수록 새 장애물이 해금(예: 레이저·프레스는 스테이지 3부터, 복합 코스는 5부터).
- 같은 장애물 연속 금지, 고위험 장애물(레이저·프레스·통나무·바·복합) 3연속 금지, 고위험 뒤 확률적 숨 고르기 발판.
- 체크포인트 간격 상한(구간당 약 55칸 이후 마무리). 발판 가장자리에 라이트 추가.

### 새 장애물 (기존: 구멍·가시·회전 바·무버·레이저·부서지는 키·계단)
| 종류 | 설명 |
|---|---|
| 징검다리 / 지그재그 섬 | 연속 점프, 좌우로 엇갈린 섬 |
| 슬라이더 | 좌우로 움직이는 발판(위에 타면 함께 이동) |
| 외나무다리 | 폭 2.6의 좁은 길, 고난도는 중간이 끊김 |
| 허들 | 낮은 장벽 — 점프하거나 빈 쪽으로 회피 |
| 통나무 | 굴러오는 통나무(전폭/반폭) |
| 슬라롬 | 통과 불가 벽을 지그재그로 통과 |
| 프레스 | 바닥 경고 점멸 후 내려찍기(파도형/통짜 게이트) |
| 컨베이어 | 옆/뒤로 밀림(걸음 수는 증가하지 않음) |
| 얼음 | 미끄러운 바닥 + 가시 |
| 낮은 레이저 | 점프로 통과(높은 레이저는 꺼질 때 통과) |
| 복합 코스 | 허들·낮은 레이저·가시 조합 (후반) |
| 보스 패턴 | 월드별: 단발 → 3갈래 부채꼴 → 빈 틈 탄막 → 혼합, 접근할수록 발사 간격 감소 |

### 밸런스 변경
- **레이저 스윕 판정**: 고속(13m/s+)·대시 시 프레임 사이로 레이저를 뚫고 지나가던 버그 수정.
- 🛡️ **보호막**: 스테이지당 1회 → **체크포인트마다 충전**(스테이지가 길어지고 장애물이 늘어난 것 반영).
- **클리어 보너스**: 목표 시간 이내 +25%, 노데스 +25% 코인. 목표 시간은 스테이지 선택 화면에 표시.
- 난이도 곡선: 스테이지 번호(70%) + 스테이지 내 진행도(30%)로 점진 상승. 징검다리·가시·바·무버 개수/속도가 이에 따라 증가.

## 수정: DOORS / BedWars / Grow a Garden / Steal a Brainrot 실행 오류
- 원인: 이 네 게임이 `THREE.CapsuleGeometry`를 쓰는데, CDN의 three.js r128에는 없는 클래스(r139에서 추가)라서 시작 직후 스크립트가 중단되고 "게임 시작" 버튼도 동작하지 않았습니다.
- 해결: 네 게임이 공통으로 불러오는 `public/games/bwcore.js` 맨 위에 호환 코드를 추가했습니다(CapsuleGeometry가 없을 때만 동작). 다른 파일은 그대로입니다.

## TOP10 랭킹 보드
`supabase/setup.sql` 맨 아래의 `speed_leaderboard` 부분을 Supabase SQL Editor에서 한 번 실행해야 스피드 키보드 탈출의 🏅 TOP10 랭킹이 표시됩니다.


## 스피드 키보드 탈출 — Ultimate Edition 품질 업그레이드
- 기존 4개 월드(총 117개 맵)의 스테이지 구성, 진행도 저장 키, 보상 구조를 유지하면서 월드 전반의 시각 효과를 개선했습니다.
- 모든 맵에 월드 테마 색상의 별빛 파티클과 네온 비콘을 추가해 코스의 공간감과 방향 가독성을 높였습니다.
- 이동형 중력 소용돌이가 실제로 좌우 이동하며 플레이어를 끌어당기도록 물리 업데이트를 연결했습니다.
- 피격 시 짧은 카메라 충격 효과와 클리어 결과의 S/A/B 등급 피드백을 추가했습니다.
- 메뉴, HUD, 버튼, 모달을 글래스/네온 스타일로 다듬고 모바일 화면 배치를 보강했습니다.
- 스테이지를 다시 만들 때 스테이지 전용 GPU 리소스를 정리하도록 해 반복 플레이 중 메모리 누적 위험을 줄였습니다.
- 기존 `speed_keyboard_escape_v1` 저장 키를 유지하므로 기존 스피드·코인·승리·환생·클리어 기록은 그대로 이어집니다.


## Galaxy World 5 업데이트
- Galaxy World 5 신규 맵 35개 추가 (총 5개 월드, 152개 맵)
- 신규 장애물 3종: 좌우 왕복 레일, 타이밍 셔터, 근접 지뢰
- 5개 맵마다 보스전 배치, 월드 5 스피드 해금 요구량은 이전 월드 마지막 스테이지 기준 8.5%씩 상승하도록 완화
- 월드 5 길이 증가폭을 완만하게 조정하고, 신규 장애물의 경고/회피 시간을 제공
