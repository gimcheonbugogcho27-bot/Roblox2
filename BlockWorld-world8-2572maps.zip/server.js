import express from 'express';
import { createClient } from '@supabase/supabase-js';
import { timingSafeEqual } from 'node:crypto';
import path from 'path';
import { fileURLToPath } from 'url';
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(express.json({limit:'32kb'}));
const STUDENTS=['김예은','김윤솔','김재은','나헤지','박솔아','박주아','박준희','송지아','신다원','전소현','전시은','주예진','김규담','김성현','김지유','김헤준','박서한','박우준','신유찬','안재현','이서빈','이승운','이시우','장재훈','전지훈','정유재','안시후'];
const studentEmail=(i)=>`bw2student${String(i+1).padStart(2,'0')}@blockworld2.invalid`;
app.post('/api/setup/class-accounts',async(req,res)=>{
  try{
    const secret=String(req.get('x-class-setup-secret')||'');
    const expected=String(process.env.CLASS_ACCOUNT_SETUP_SECRET||'');
    if(!expected||secret.length!==expected.length||!timingSafeEqual(Buffer.from(secret),Buffer.from(expected)))return res.status(403).json({error:'설정 비밀번호가 올바르지 않습니다.'});
    const url=process.env.SUPABASE_URL||process.env.VITE_SUPABASE_URL;
    const serviceKey=process.env.SUPABASE_SERVICE_ROLE_KEY;
    if(!url||!serviceKey)return res.status(500).json({error:'Render에 SUPABASE_URL(또는 VITE_SUPABASE_URL)과 SUPABASE_SERVICE_ROLE_KEY 환경변수를 설정하세요.'});
    const admin=createClient(url,serviceKey,{auth:{autoRefreshToken:false,persistSession:false}});
    const {data:list,error:listError}=await admin.auth.admin.listUsers({page:1,perPage:1000});
    if(listError)throw listError;
    const byEmail=new Map((list.users||[]).map(u=>[u.email,u]));
    const results=[];
    for(let i=0;i<STUDENTS.length;i++){
      const email=studentEmail(i), name=STUDENTS[i], existing=byEmail.get(email);
      let result;
      if(existing){const r=await admin.auth.admin.updateUserById(existing.id,{password:'44class',email_confirm:true,user_metadata:{...(existing.user_metadata||{}),username:name,display_name:name}});if(r.error)throw new Error(name+': '+r.error.message);result='updated';}
      else{const r=await admin.auth.admin.createUser({email,password:'44class',email_confirm:true,user_metadata:{username:name,display_name:name}});if(r.error)throw new Error(name+': '+r.error.message);result='created';}
      results.push({username:name,status:result});
    }
    return res.json({success:true,total:results.length,created:results.filter(x=>x.status==='created').length,updated:results.filter(x=>x.status==='updated').length,accounts:results});
  }catch(e){return res.status(500).json({error:e.message||'계정 생성 실패'});}
});
const dist=path.join(__dirname,'dist');
// HTML(게임 파일 포함)은 항상 최신 버전 확인, 그 외 파일은 1시간 캐시
app.use(express.static(dist,{maxAge:'1h',setHeaders(res,filePath){if(filePath.endsWith('.html')||filePath.includes(path.sep+'games'+path.sep))res.setHeader('Cache-Control','no-cache, must-revalidate')}}));
app.get('*',(req,res)=>{res.setHeader('Cache-Control','no-cache, must-revalidate');res.sendFile(path.join(dist,'index.html'))});
const port=process.env.PORT||10000;
app.listen(port,'0.0.0.0',()=>console.log(`BlockWorld 2 running on ${port}`));
