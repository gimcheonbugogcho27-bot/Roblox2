/* Steal a Brainrot 업그레이드: 5등급 수집품 · 진열대 패시브 수입 · 도둑 AI · 방어막 · 라운드 · 상점 */
(function(){
const C=window.__ctx;if(!C||C.MODE!=='brainrot'||!window.BW||!BW.S)return;C.own=true;
const {THREE,scene,items}=C,$=id=>document.getElementById(id),up=BW.up,S=BW.S;
items.forEach(o=>{scene.remove(o.mesh);if(o.ring)scene.remove(o.ring)});items.length=0;
scene.children.filter(o=>o.isGroup&&o.position.x===14&&o.position.z===-14).forEach(o=>scene.remove(o));
const TI=[{n:'일반',c:0x9aa7b5,v:5,w:60,inc:.5,nm:['뽀짝 바나나','졸린 감자','둥둥 구름']},{n:'레어',c:0x4aa3ff,v:15,w:25,inc:1.5,nm:['번개 상어','춤추는 선인장','쿵쿵 고양이']},{n:'에픽',c:0xb44dff,v:50,w:10,inc:5,nm:['핑크 문어','로켓 두더지','네온 펭귄']},{n:'전설',c:0xffc83d,v:200,w:4,inc:20,nm:['황금 드래곤','우주 고래']},{n:'신화',c:0xff3da6,v:800,w:1,inc:80,nm:['은하 유니콘']}];
const DEFS=[
{id:'spd',name:'👟 이동속도',max:5,cost:l=>30*(l+1),desc:l=>'+'+l*11+'%'},
{id:'cap',name:'🎒 가방 크기',max:4,cost:l=>Math.round(50*Math.pow(l+1,1.5)),desc:l=>'한 번에 '+(1+l)+'개 운반'},
{id:'slot',name:'🏛️ 진열대 확장',max:3,cost:l=>Math.round(80*Math.pow(l+1,1.6)),desc:l=>'진열대 '+(6+2*l)+'칸'},
{id:'shield',name:'🛡️ 방어막',max:5,cost:l=>40*(l+1),desc:l=>'지속 '+(8+3*l)+'초 · 재사용 '+(45-4*l)+'초'},
{id:'luck',name:'🍀 희귀 확률',max:5,cost:l=>Math.round(45*Math.pow(l+1,1.4)),desc:l=>'희귀 등급 확률 +'+l*35+'%'},
{id:'inc',name:'📈 수입 증가',max:5,cost:l=>Math.round(55*Math.pow(l+1,1.5)),desc:l=>'진열대 수입 +'+l*20+'%'}];
BW.setShop(DEFS,()=>peds());
/* 크리처 모델 */
function mk(t,sc){const G=new THREE.Group(),c=TI[t].c,B=new THREE.MeshStandardMaterial({color:c,roughness:.45,emissive:c,emissiveIntensity:.18+t*.08}),W=new THREE.MeshBasicMaterial({color:0xffffff}),K=new THREE.MeshBasicMaterial({color:0x111111});
const b=new THREE.Mesh(new THREE.SphereGeometry(.5,16,12),B);b.scale.set(1,1.1,1);b.position.y=.6;G.add(b);
for(const x of[-.18,.18]){const e=new THREE.Mesh(new THREE.SphereGeometry(.12,10,8),W);e.position.set(x,.8,.4);const p=new THREE.Mesh(new THREE.SphereGeometry(.06,8,6),K);p.position.set(x,.8,.5);G.add(e,p)}
for(const x of[-.22,.22]){const f=new THREE.Mesh(new THREE.CylinderGeometry(.1,.12,.18,8),B);f.position.set(x,.08,.05);G.add(f)}
if(t>=2){const a=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,.4,5),B);a.position.y=1.35;const o=new THREE.Mesh(new THREE.SphereGeometry(.09,8,6),new THREE.MeshBasicMaterial({color:c}));o.position.y=1.58;G.add(a,o)}
if(t>=3){const cr=new THREE.Mesh(new THREE.ConeGeometry(.3,.35,5),new THREE.MeshStandardMaterial({color:0xffe27a,emissive:0xffc800,emissiveIntensity:.8}));cr.position.y=1.28;G.add(cr)}
if(t>=4){const r=new THREE.Mesh(new THREE.TorusGeometry(.7,.03,6,24),new THREE.MeshBasicMaterial({color:0xffffff}));r.position.y=.7;r.rotation.x=Math.PI/2;G.add(r)}
G.traverse(o=>{if(o.isMesh)o.castShadow=true});G.scale.setScalar(sc||1);return G}
/* 진열대 */
const PD=[];for(let i=0;i<12;i++){const a=i/12*6.283,g=new THREE.Mesh(new THREE.CylinderGeometry(.5,.6,.5,12),new THREE.MeshLambertMaterial({color:0x40345d}));g.position.set(Math.cos(a)*3.5,.45,Math.sin(a)*3.5);scene.add(g);PD.push({g,x:g.position.x,z:g.position.z,it:null,i})}
function peds(){const n=6+2*up('slot');PD.forEach(p=>{p.open=p.i<n;p.g.material.color.setHex(p.open?0x6a4fa8:0x2a2238)})}peds();
/* 방어막 */
const shM=new THREE.Mesh(new THREE.SphereGeometry(5.6,24,16),new THREE.MeshBasicMaterial({color:0x5bd0ff,transparent:true,opacity:.16,side:THREE.DoubleSide,depthWrite:false}));shM.visible=false;scene.add(shM);
const sb=document.createElement('button');sb.style.cssText='position:fixed;right:14px;bottom:96px;z-index:6;width:58px;height:58px;border-radius:50%;border:2px solid #fff8;background:#17243dcc;color:#fff;font-size:22px;touch-action:manipulation';sb.textContent='🛡️';document.body.appendChild(sb);
let shT=0,shCd=0;sb.onclick=()=>{if(shCd>0){BW.sfx('err');BW.banner('방어막 재사용 '+Math.ceil(shCd)+'초');return}shT=8+3*up('shield');shCd=45-4*up('shield');BW.sfx('level');BW.banner('🛡️ 기지 방어막 발동!')};
addEventListener('keydown',e=>{if(e.key.toLowerCase()==='q')sb.click()});
/* 상태 */
let carry=[],carryM=[],spawns=[],th=[],round=1,roundT=90,earned=0,vault=0,rEnd=false,vt=0;
for(let i=0;i<5;i++){const m=new THREE.Mesh(new THREE.SphereGeometry(.28,10,8),new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xffffff,emissiveIntensity:.5}));m.visible=false;scene.add(m);carryM.push(m)}
const cap=()=>1+up('cap');
function roll(){const bonus=1+.35*up('luck')+.12*(round-1);let tot=0;const w=TI.map((t,i)=>{const x=t.w*(i?bonus:1);tot+=x;return x});let r=Math.random()*tot;for(let i=0;i<5;i++){r-=w[i];if(r<=0)return i}return 0}
function spawn(){const t=roll(),nm=TI[t].nm[Math.floor(Math.random()*TI[t].nm.length)],a=Math.random()*6.283,r=t>=3?14+Math.random()*4:8+Math.random()*8;
 const g=mk(t,1+t*.12);g.position.set(Math.cos(a)*r,0,Math.sin(a)*r);const lb=BW.label(nm+' ['+TI[t].n+']','#'+TI[t].c.toString(16).padStart(6,'0'));lb.position.y=2.3;g.add(lb);scene.add(g);spawns.push({g,t,nm,x:g.position.x,z:g.position.z,ph:Math.random()*6})}
function mkThief(){const g=new THREE.Group(),b=new THREE.Mesh(new THREE.CapsuleGeometry(.4,.6,4,8),new THREE.MeshLambertMaterial({color:0xc2203a}));b.position.y=1.1;const h=new THREE.Mesh(new THREE.SphereGeometry(.34,12,10),new THREE.MeshLambertMaterial({color:0x2a2a2a}));h.position.y=1.85;const e=new THREE.Mesh(new THREE.BoxGeometry(.5,.1,.1),new THREE.MeshBasicMaterial({color:0xff3b3b}));e.position.set(0,1.88,.3);g.add(b,h,e);
 const a=Math.random()*6.283;g.position.set(Math.cos(a)*18,0,Math.sin(a)*18);scene.add(g);return{g,loot:null,lm:null,cd:0}}
function resetThieves(){th.forEach(t=>{scene.remove(t.g);t.lm&&scene.remove(t.lm)});th=[];for(let i=0;i<Math.min(3,1+Math.floor((round-1)/2));i++)th.push(mkThief())}
for(let i=0;i<12;i++)spawn();resetThieves();
function place(it){const p=PD.find(q=>q.open&&!q.it);if(!p)return false;const m=mk(it.t,.6);m.position.set(p.x,.7,p.z);scene.add(m);p.it={...it,m};return true}
const inc=it=>TI[it.t].inc*(1+.2*up('inc'));
C.ext={
act(){const px=C.px,pz=C.pz;
 const t=th.find(x=>x.loot&&Math.hypot(x.g.position.x-px,x.g.position.z-pz)<3.6);
 if(t){const it=t.loot;t.loot=null;scene.remove(t.lm);t.lm=null;if(!place(it)&&carry.length<cap())carry.push(it);BW.sfx('win');BW.burst(t.g.position.x,1.5,t.g.position.z,0xffffff,30);BW.banner('되찾았어요! 💪');BW.xp(15);t.g.position.set(Math.cos(1)*18,0,Math.sin(1)*18);return}
 if(Math.hypot(px,pz)<6){let n=0;while(carry.length&&PD.some(p=>p.open&&!p.it)){const it=carry.shift();place(it);const v=Math.round(it.v*.3);BW.coins(v);earned+=v;n++;BW.burst(px,1.5,pz,TI[it.t].c,24)}
  if(n){BW.sfx('win');BW.xp(8*n);BW.banner('진열 완료! ×'+n)}else if(carry.length){BW.sfx('err');BW.banner('진열대가 가득! 🏛️ 상점에서 확장')}
  else if(vault>=1){const v=Math.floor(vault);vault-=v;BW.coins(v);earned+=v;BW.sfx('pick');BW.float('+'+v+' 🪙',px,2.8,pz)}else{BW.sfx('err');BW.banner('물건을 주워 오세요!')}return}
 if(carry.length>=cap()){BW.sfx('err');BW.banner('가방 가득! 기지로 가세요');return}
 const s=spawns.filter(o=>Math.hypot(o.x-px,o.z-pz)<3.4).sort((a,b)=>Math.hypot(a.x-px,a.z-pz)-Math.hypot(b.x-px,b.z-pz))[0];
 if(!s){BW.sfx('err');BW.banner('수집품 가까이 가세요');return}
 spawns.splice(spawns.indexOf(s),1);scene.remove(s.g);carry.push({t:s.t,nm:s.nm,v:TI[s.t].v});BW.sfx(s.t>=3?'level':'pick');BW.burst(s.x,1.2,s.z,TI[s.t].c,26+s.t*8);BW.banner(s.nm+' ['+TI[s.t].n+'] 획득!');if(s.t>=3)BW.shake(.2);setTimeout(spawn,5000)},
frame(dt,now){const px=C.px,pz=C.pz;C.spd=8*(1+.11*up('spd'));
 C.px=Math.max(-19,Math.min(19,C.px));C.pz=Math.max(-19,Math.min(19,C.pz));
 if(rEnd){rEnd=false;round++;roundT=90;earned=0;resetThieves();BW.banner('🔥 라운드 '+round+' 시작! 도둑 '+th.length+'명')}
 roundT-=dt;BW.timer(roundT);
 if(roundT<=0){rEnd=true;BW.best(earned);BW.xp(30+round*10);BW.win('✅ 라운드 '+round+' 종료','이번 라운드 수익 🪙 '+earned+'\n보유 🪙 '+Math.floor(S.coins)+'\n다음 라운드: 도둑 '+Math.min(3,1+Math.floor(round/2))+'명\n상점(🛒)에서 강화하세요!',true);return}
 spawns.forEach(o=>{o.g.position.y=Math.sin(now*.003+o.ph)*.12;o.g.rotation.y+=dt*.9});
 /* 수입 */
 PD.forEach(p=>{if(p.it){vault+=inc(p.it)*dt;p.it.m.position.y=.7+Math.sin(now*.003+p.i)*.06;p.it.m.rotation.y+=dt}});
 if(Math.hypot(px,pz)<6&&vault>=1&&now-vt>1000){vt=now;const v=Math.floor(vault);vault-=v;BW.coins(v);earned+=v;BW.float('+'+v+' 🪙',px,2.8,pz,'#ffe14d')}
 /* 방어막 */
 shT=Math.max(0,shT-dt);shCd=Math.max(0,shCd-dt);shM.visible=shT>0;if(shT>0){shM.rotation.y+=dt;shM.material.opacity=.14+.05*Math.sin(now*.01)}sb.style.opacity=shCd>0?.5:1;sb.textContent=shCd>0?Math.ceil(shCd):'🛡️';
 /* 운반 표시 */
 carryM.forEach((m,i)=>{const it=carry[i];m.visible=!!it;if(it){m.material.color.setHex(TI[it.t].c);m.material.emissive.setHex(TI[it.t].c);m.position.set(px,2.7+i*.5+Math.sin(now*.006+i)*.08,pz)}});
 /* 도둑 */
 th.forEach((t,i)=>{const g=t.g,sp=3.4+round*.25;t.cd-=dt;let tx,tz,s=sp;
  if(t.loot){const d=Math.hypot(g.position.x,g.position.z)||1;tx=g.position.x/d*24;tz=g.position.z/d*24;s=5.2;if(d>18.5){scene.remove(t.lm);t.lm=null;t.loot=null;BW.banner('도둑이 '+'전리품을 가지고 도망쳤어요 😢');g.position.set(-g.position.x*.9,0,-g.position.z*.9)}}
  else if(carry.length){tx=px;tz=pz;if(Math.hypot(g.position.x-px,g.position.z-pz)<1.6&&t.cd<=0){t.cd=3;const it=carry.sort((a,b)=>b.v-a.v).shift();t.loot=it;t.lm=mk(it.t,.5);scene.add(t.lm);BW.flash('#ff1b3c');BW.sfx('hurt');BW.shake(.3);BW.banner('도둑이 '+it.nm+'을(를) 훔쳤어요! 잡으세요!')}}
  else{const has=PD.some(p=>p.it);if(has&&shT<=0){tx=0;tz=0;const dd=Math.hypot(g.position.x,g.position.z);if(dd<4.2&&t.cd<=0){const q=PD.filter(p=>p.it).sort((a,b)=>b.it.v-a.it.v)[0];t.cd=4;t.loot=q.it;scene.remove(q.it.m);t.lm=mk(q.it.t,.5);scene.add(t.lm);q.it=null;BW.flash('#ff1b3c');BW.sfx('hurt');BW.banner('도둑이 진열대를 털었어요! 🛡️ 방어막(Q)')}}
   else{const a=now*.0006+i*2.1;tx=Math.cos(a)*10;tz=Math.sin(a)*10;s=2}}
  const dx=tx-g.position.x,dz=tz-g.position.z,d=Math.hypot(dx,dz)||1;if(d>.4){g.position.x+=dx/d*s*dt;g.position.z+=dz/d*s*dt;g.rotation.y=Math.atan2(dx,dz)}
  if(shT>0&&!t.loot){const bd=Math.hypot(g.position.x,g.position.z);if(bd<5.8){g.position.x+=g.position.x/bd*8*dt;g.position.z+=g.position.z/bd*8*dt}}
  g.position.y=Math.abs(Math.sin(now*.01+i))*.12;if(t.lm)t.lm.position.set(g.position.x,2.7,g.position.z)});
 const st=$('stats');if(st&&now-(this.t||0)>300){this.t=now;st.textContent='🪙 '+Math.floor(S.coins)+' · 🎒 '+carry.length+'/'+cap()+' · 금고 '+Math.floor(vault)+' · R'+round}}};
})();
