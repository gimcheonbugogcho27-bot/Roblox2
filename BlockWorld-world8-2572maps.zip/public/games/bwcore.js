/* BW core: 사운드 · 파티클 · 레벨/저장 · 멀티 · 하늘/먼지/바닥 · 연출 (speed 퀄리티 기준) */
/* 호환 패치: three.js r128에는 CapsuleGeometry가 없음(r139에서 추가) → doors/garden/brainrot/bedwars가 시작 직후 죽던 원인.
   없을 때만 LatheGeometry로 같은 모양(반지름·몸통길이·캡 분할·둘레 분할)의 캡슐을 만들어 채워 넣는다. */
if(window.THREE&&!THREE.CapsuleGeometry){THREE.CapsuleGeometry=function(radius,length,capSegments,radialSegments){
const r=radius===undefined?1:radius,l=length===undefined?1:length,cs=Math.max(1,capSegments|0||4),rs=Math.max(12,(radialSegments|0||8)*2),pts=[];
for(let i=0;i<=cs;i++){const a=-Math.PI/2+i/cs*Math.PI/2;pts.push(new THREE.Vector2(i===0?0:Math.cos(a)*r,-l/2+Math.sin(a)*r))}
for(let i=0;i<=cs;i++){const a=i/cs*Math.PI/2;pts.push(new THREE.Vector2(i===cs?0:Math.cos(a)*r,l/2+Math.sin(a)*r))}
return new THREE.LatheGeometry(pts,rs)}}
(function(){
const BW=window.BW={};let coinEl,dirty=0,lastSv=0,T,scene,camera,MODE,AC,S,remotes={},lastSend=0,shakeT=0,flashEl,dangerEl,hpEl,lvEl,tmEl,fl,P,PN=260,pArr=[],dust;
const $=id=>document.getElementById(id);
const KEY=()=>'bw_'+MODE+'_v2';
const PAL={doors:{sky:[0x0b0d16,0x1b1f30],dust:0xffd9a0,floor:['#2d2b33','#34323b']},bedwars:{sky:[0x4fa9ff,0xcfeaff],dust:0xffffff,floor:['#4f9c65','#58a870']},garden:{sky:[0x58b8ff,0xdff4ff],dust:0xfff3b0,floor:['#4b9b4a','#58ad55']},brainrot:{sky:[0x31206b,0xe27ad6],dust:0xff9bf0,floor:['#6d57a0','#7a63b0']}};
BW.sfx=t=>{try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();if(S&&S.mute)return;
const D={pick:[[660,.08,'triangle'],[990,.12,'triangle']],plant:[[330,.07,'sine'],[440,.1,'sine']],water:[[520,.05,'sine'],[400,.08,'sine'],[620,.06,'sine']],win:[[523,.12,'square'],[659,.12,'square'],[784,.12,'square'],[1047,.3,'square']],hurt:[[160,.14,'sawtooth'],[90,.25,'sawtooth']],level:[[440,.1,'triangle'],[554,.1,'triangle'],[659,.1,'triangle'],[880,.24,'triangle']],err:[[200,.12,'square']],jump:[[300,.06,'sine'],[520,.09,'sine']],beat:[[70,.12,'sine'],[60,.18,'sine']]}[t]||[[440,.08,'sine']];
let at=AC.currentTime;D.forEach(([f,d,w])=>{const o=AC.createOscillator(),g=AC.createGain();o.type=w;o.frequency.value=f;g.gain.setValueAtTime(.001,at);g.gain.exponentialRampToValueAtTime(.13,at+.01);g.gain.exponentialRampToValueAtTime(.001,at+d);o.connect(g);g.connect(AC.destination);o.start(at);o.stop(at+d+.03);at+=d*.8})}catch(e){}};
/* 저장 / 레벨 */
BW.save=()=>{try{localStorage.setItem(KEY(),JSON.stringify(S))}catch(e){}try{if(parent!==window)parent.postMessage({type:'bw2:save',game:MODE,save:S},'*')}catch(e){}};
const need=l=>Math.round(30*Math.pow(l,1.45));
BW.xp=n=>{S.xp+=n;S.total+=n;let up=false;while(S.xp>=need(S.lv)){S.xp-=need(S.lv);S.lv++;up=true}
if(up){BW.sfx('level');BW.banner('⭐ LEVEL '+S.lv+' 달성!');BW.burst(BW.p.x,1.5,BW.p.z,0xffd24d,40)}hud();BW.save()};
function hud(){if(!lvEl)return;lvEl.firstChild.style.width=Math.min(100,S.xp/need(S.lv)*100)+'%';lvEl.lastChild.textContent='Lv.'+S.lv+'  ·  최고기록 '+S.best}
BW.best=v=>{if(v>S.best){S.best=v;hud();BW.save();return true}return false};
BW.banner=t=>{const b=$('banner');if(!b)return;b.textContent=t;clearTimeout(BW._bt);BW._bt=setTimeout(()=>{if(b.textContent===t)b.textContent=''},1900)};
BW.hp=v=>{if(!hpEl)return;hpEl.firstChild.style.width=Math.max(0,v)+'%';hpEl.style.display=v<100?'block':'none'};
BW.label=(txt,col)=>{const c=document.createElement('canvas');c.width=256;c.height=48;const g=c.getContext('2d');g.font='bold 26px sans-serif';g.textAlign='center';g.lineWidth=6;g.strokeStyle='#000';g.strokeText(txt,128,34);g.fillStyle=col||'#fff';g.fillText(txt,128,34);const s=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(c),depthTest:false,transparent:true}));s.scale.set(2.8,.52,1);s.renderOrder=9;return s};
const pill=()=>{if(coinEl)coinEl.textContent='🪙 '+Math.floor(S.coins)+(BW.defs?'  🛒':'')};
BW.coins=n=>{S.coins=Math.max(0,S.coins+n);dirty=1;pill()};BW.up=id=>S.up[id]||0;
BW.setShop=(defs,onUp)=>{BW.defs=defs;BW.onUp=onUp;coinEl.style.display='block';pill()};
BW.shop=()=>{if(!BW.defs)return;const old=$('bwshop');if(old)old.remove();const o=document.createElement('div');o.className='bwwin';o.id='bwshop';document.body.appendChild(o);
const render=()=>{o.innerHTML='<div style="min-width:min(88vw,380px);max-height:86vh;overflow:auto"><h2>🛒 상점</h2><p style="margin:0 0 10px">보유 🪙 '+Math.floor(S.coins)+'</p>'+BW.defs.map(d=>{const lv=S.up[d.id]||0,cost=d.cost(lv);return '<div class="bwrow"><div><b>'+d.name+'</b> <small>Lv.'+lv+'/'+d.max+'</small><br><small>'+d.desc(lv)+'</small></div>'+(lv>=d.max?'<b>MAX</b>':'<button data-id="'+d.id+'"'+(S.coins<cost?' disabled':'')+'>🪙 '+cost+'</button>')+'</div>'}).join('')+'<button id="bwx" style="margin-top:12px;background:#555;box-shadow:0 4px 0 #333">닫기</button></div>';
o.querySelectorAll('button[data-id]').forEach(b=>b.onclick=()=>{const d=BW.defs.find(x=>x.id===b.dataset.id),lv=S.up[d.id]||0,cost=d.cost(lv);if(lv>=d.max||S.coins<cost)return;S.coins-=cost;S.up[d.id]=lv+1;BW.sfx('level');pill();BW.save();BW.onUp&&BW.onUp(d.id);render()});o.querySelector('#bwx').onclick=()=>o.remove()};render()};
BW.timer=t=>{if(!tmEl)return;tmEl.style.display=t==null?'none':'block';if(t!=null)tmEl.textContent='⏱ '+Math.max(0,Math.ceil(t))+'s'};
BW.flash=c=>{flashEl.style.background=c;flashEl.style.opacity=.55;setTimeout(()=>flashEl.style.opacity=0,120)};
BW.danger=v=>{dangerEl.style.opacity=Math.max(0,Math.min(1,v))};
BW.shake=v=>{shakeT=Math.max(shakeT,v)};
/* 파티클 */
BW.burst=(x,y,z,c,n)=>{const col=new T.Color(c);for(let i=0;i<n&&pArr.length<PN;i++){const a=Math.random()*6.28,s=1+Math.random()*4;pArr.push({x,y,z,vx:Math.cos(a)*s,vy:2+Math.random()*4,vz:Math.sin(a)*s,l:.7+Math.random()*.5,r:col.r,g:col.g,b:col.b})}};
BW.float=(txt,x,y,z,color)=>{const v=new T.Vector3(x,y,z).project(camera);if(v.z>1)return;const e=document.createElement('div');e.className='bwfl';e.textContent=txt;e.style.left=(v.x*.5+.5)*innerWidth+'px';e.style.top=(-v.y*.5+.5)*innerHeight+'px';e.style.color=color||'#ffe14d';fl.appendChild(e);setTimeout(()=>e.remove(),1100)};
/* 결과 화면 */
BW.win=(title,sub,cont)=>{BW.sfx('win');BW.shake(.3);const o=document.createElement('div');o.className='bwwin';o.innerHTML='<div><h2>'+title+'</h2><p>'+sub+'</p><button id="bwA">'+(cont?'계속하기':'다시 하기')+'</button></div>';document.body.appendChild(o);BW.over=true;
o.querySelector('button').onclick=()=>{o.remove();BW.over=false;if(!cont)location.reload()};BW.save()};
/* 초기화 */
BW.init=o=>{T=o.THREE;scene=o.scene;camera=o.camera;MODE=o.mode;BW.p={x:0,y:0,z:0};
S={lv:1,xp:0,total:0,best:0,mute:false,coins:0,up:{}};try{Object.assign(S,JSON.parse(localStorage.getItem(KEY())||'{}'))}catch(e){}if(!S.up)S.up={};BW.S=S;
const css=document.createElement('style');css.textContent=`
#start{background:radial-gradient(ellipse at 50% 30%,#2a2058ee,#07101df5)!important;backdrop-filter:blur(6px)}
#start h1{font-size:clamp(34px,8vw,64px)!important;letter-spacing:2px;background:linear-gradient(90deg,#ffd24d,#ff6aa8,#6ee6bd,#ffd24d);background-size:300%;-webkit-background-clip:text;background-clip:text;color:transparent;animation:bwg 5s linear infinite;filter:drop-shadow(0 4px 12px #0008)}
@keyframes bwg{to{background-position:300%}}
#go{background:linear-gradient(180deg,#8bf5cf,#3ac590)!important;box-shadow:0 5px 0 #1d7a58,0 10px 24px #0007;transition:transform .1s}#go:active{transform:translateY(3px)}
.act{backdrop-filter:blur(4px);box-shadow:0 4px 14px #0006}
#bwv{position:fixed;inset:0;pointer-events:none;z-index:2;background:radial-gradient(ellipse at center,transparent 55%,#000a 100%)}
#bwf,#bwd{position:fixed;inset:0;pointer-events:none;z-index:7;opacity:0;transition:opacity .25s}#bwd{background:radial-gradient(ellipse at center,transparent 35%,#d0001bbb 100%);z-index:6}
#bwl{position:fixed;left:50%;bottom:10px;transform:translateX(-50%);width:min(56%,420px);height:22px;background:#000a;border:2px solid #fff4;border-radius:14px;overflow:hidden;pointer-events:none;z-index:3}
#bwl>i{display:block;height:100%;width:0;background:linear-gradient(90deg,#35e07a,#ffd24d);transition:width .3s}#bwl>b{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:11px;text-shadow:0 1px 2px #000}
#bwh{position:fixed;left:10px;top:64px;width:140px;height:12px;background:#000a;border:2px solid #fff4;border-radius:8px;overflow:hidden;z-index:3;display:none}#bwh>i{display:block;height:100%;background:linear-gradient(90deg,#ff3b5c,#ff9a5c);transition:width .2s}
#bwt{position:fixed;left:50%;top:56px;transform:translateX(-50%);background:#000b;border:2px solid #fff4;border-radius:12px;padding:4px 14px;font-weight:900;z-index:3;display:none}
.bwfl{position:fixed;transform:translate(-50%,-50%);font-weight:900;font-size:20px;text-shadow:0 2px 0 #000,0 0 6px #000;pointer-events:none;z-index:8;animation:bwr 1.1s ease-out forwards}@keyframes bwr{to{transform:translate(-50%,-150%);opacity:0}}
.bwwin{position:fixed;inset:0;z-index:20;background:#000b;display:flex;align-items:center;justify-content:center;text-align:center;animation:bwi .4s}@keyframes bwi{from{opacity:0}}
.bwwin>div{background:linear-gradient(160deg,#2a1c4a,#14102a);border:3px solid #ffd24d;border-radius:20px;padding:26px 34px;max-width:86%}.bwwin h2{font-size:30px;color:#ffd24d;margin:0 0 8px}.bwwin p{line-height:1.7;margin:0 0 16px;color:#e7e0ff;white-space:pre-line}
.bwwin button{padding:12px 28px;border:0;border-radius:12px;background:#ff4fa3;color:#fff;font-weight:900;font-size:16px;box-shadow:0 4px 0 #a3235f}
#bwc{position:fixed;right:10px;top:84px;z-index:4;background:#000a;border:2px solid #ffd24d88;border-radius:10px;color:#ffe14d;padding:3px 9px;font-size:14px;font-weight:900;cursor:pointer;display:none}
.bwrow{display:flex;justify-content:space-between;align-items:center;gap:12px;background:#0005;border-radius:12px;padding:8px 10px;margin:6px 0;text-align:left}.bwrow small{opacity:.8}.bwrow button{padding:8px 12px;font-size:14px}.bwrow button:disabled{opacity:.4}
#bws{position:fixed;right:10px;top:48px;z-index:4;background:#000a;border:2px solid #fff4;border-radius:10px;color:#fff;padding:3px 9px;font-size:14px}`;document.head.appendChild(css);
const mk=(id,html)=>{const d=document.createElement('div');d.id=id;if(html)d.innerHTML=html;document.body.appendChild(d);return d};
mk('bwv');flashEl=mk('bwf');dangerEl=mk('bwd');fl=mk('bwfl0');lvEl=mk('bwl','<i></i><b></b>');hpEl=mk('bwh','<i></i>');tmEl=mk('bwt');coinEl=mk('bwc');coinEl.onclick=()=>BW.shop();const sb=mk('bws','🔊');
sb.style.pointerEvents='auto';sb.onclick=()=>{S.mute=!S.mute;sb.textContent=S.mute?'🔇':'🔊';BW.save()};sb.textContent=S.mute?'🔇':'🔊';hud();
/* 하늘 돔 */
const pal=PAL[MODE]||PAL.garden;const dome=new T.Mesh(new T.SphereGeometry(170,24,12),new T.ShaderMaterial({side:T.BackSide,depthWrite:false,fog:false,uniforms:{a:{value:new T.Color(pal.sky[0])},b:{value:new T.Color(pal.sky[1])}},vertexShader:'varying float h;void main(){h=normalize(position).y;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',fragmentShader:'uniform vec3 a,b;varying float h;void main(){gl_FragColor=vec4(mix(b,a,clamp(h*1.6,0.,1.)),1.);}'}));dome.renderOrder=-9;scene.add(dome);BW.dome=dome;
/* 바닥 텍스처 */
if(o.floor){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.fillStyle=pal.floor[0];g.fillRect(0,0,128,128);for(let i=0;i<900;i++){g.fillStyle=Math.random()<.5?pal.floor[1]:'#0002';g.fillRect(Math.random()*128,Math.random()*128,2+Math.random()*3,2+Math.random()*3)}
if(MODE==='doors'){g.strokeStyle='#0005';g.lineWidth=3;g.strokeRect(0,0,128,128)}const tx=new T.CanvasTexture(c);tx.wrapS=tx.wrapT=T.RepeatWrapping;tx.repeat.set(30,30);tx.encoding=T.sRGBEncoding;tx.anisotropy=4;o.floor.material.map=tx;o.floor.material.color.set(0xffffff);o.floor.material.needsUpdate=true}
/* 떠다니는 먼지/반딧불 */
const dg=new T.BufferGeometry(),dp=new Float32Array(150*3);for(let i=0;i<150;i++){dp[i*3]=(Math.random()-.5)*60;dp[i*3+1]=Math.random()*8;dp[i*3+2]=(Math.random()-.5)*60}dg.setAttribute('position',new T.BufferAttribute(dp,3));
dust=new T.Points(dg,new T.PointsMaterial({color:pal.dust,size:.16,transparent:true,opacity:.7,depthWrite:false,blending:T.AdditiveBlending}));scene.add(dust);
/* 파티클 풀 */
const pg=new T.BufferGeometry();pg.setAttribute('position',new T.BufferAttribute(new Float32Array(PN*3),3));pg.setAttribute('color',new T.BufferAttribute(new Float32Array(PN*3),3));
P=new T.Points(pg,new T.PointsMaterial({size:.4,vertexColors:true,transparent:true,depthWrite:false,blending:T.AdditiveBlending}));P.frustumCulled=false;scene.add(P);
/* 키보드 */
const K={};const upd=()=>{BW.kb=!!(K.w||K.a||K.s||K.d||K.arrowup||K.arrowdown);if(o.joy&&o.joy.id===null){o.joy.x=(K.d?1:0)-(K.a?1:0);o.joy.y=(K.s||K.arrowdown?1:0)-(K.w||K.arrowup?1:0)}};
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k===' '){e.preventDefault();o.jump&&o.jump();return}if(k==='e'||k==='enter'){o.act&&o.act();return}K[k]=1;upd()});addEventListener('keyup',e=>{K[e.key.toLowerCase()]=0;upd()});
/* 계정/클라우드 저장 · 원격 플레이어 */
addEventListener('message',e=>{const d=e.data;if(!d)return;if(d.type==='bw2:load-save'&&d.game===MODE&&d.save&&!BW._cl){BW._cl=1;if((d.save.total||0)>=S.total){Object.assign(S,d.save);hud();try{localStorage.setItem(KEY(),JSON.stringify(S))}catch(_){}}}
else if(d.type==='bw2:remote'&&d.player&&d.player.game===MODE)remote(d.player)});
};
function tag(name){const c=document.createElement('canvas');c.width=256;c.height=48;const g=c.getContext('2d');g.font='bold 28px sans-serif';g.textAlign='center';g.lineWidth=6;g.strokeStyle='#000';g.strokeText(name,128,34);g.fillStyle='#fff';g.fillText(name,128,34);const s=new T.Sprite(new T.SpriteMaterial({map:new T.CanvasTexture(c),depthTest:false}));s.scale.set(2.6,.5,1);s.position.y=2.7;s.renderOrder=9;return s}
function remote(p){let r=remotes[p.id];if(!r){const g=new T.Group(),col=new T.Color().setHSL(Math.random(),.7,.55);const b=new T.Mesh(new T.CapsuleGeometry(.38,.6,4,8),new T.MeshLambertMaterial({color:col}));b.position.y=1.1;const h=new T.Mesh(new T.SphereGeometry(.32,14,10),new T.MeshLambertMaterial({color:0xf0bd91}));h.position.y=1.85;g.add(b,h,tag(p.name||'플레이어'));scene.add(g);r=remotes[p.id]={g,tx:0,ty:0,tz:0,rot:0,t:0}}
r.tx=p.x;r.ty=p.y;r.tz=p.z;r.rot=p.rotation||0;r.t=performance.now()}
/* 매 프레임 */
BW.tick=a=>{const dt=a.dt,now=a.now;if(dirty&&now-lastSv>2000){dirty=0;lastSv=now;BW.save()}
for(let i=0;i<pArr.length;i++){const q=pArr[i];q.l-=dt;if(q.l<=0){pArr.splice(i--,1);continue}q.vy-=11*dt;q.x+=q.vx*dt;q.y+=q.vy*dt;q.z+=q.vz*dt}
const pp=P.geometry.attributes.position.array,pc=P.geometry.attributes.color.array;for(let i=0;i<PN;i++){const q=pArr[i];if(q){pp[i*3]=q.x;pp[i*3+1]=Math.max(.05,q.y);pp[i*3+2]=q.z;const f=Math.min(1,q.l*1.6);pc[i*3]=q.r*f;pc[i*3+1]=q.g*f;pc[i*3+2]=q.b*f}else{pp[i*3+1]=-999}}P.geometry.attributes.position.needsUpdate=true;P.geometry.attributes.color.needsUpdate=true;
const d=dust.geometry.attributes.position.array;for(let i=0;i<150;i++){d[i*3+1]+=Math.sin(now*.001+i)*.003;d[i*3]+=Math.cos(now*.0007+i*2)*.004}dust.geometry.attributes.position.needsUpdate=true;if(a.x!=null){dust.position.set(a.x,0,a.z);BW.p.x=a.x;BW.p.y=a.y;BW.p.z=a.z}
for(const id in remotes){const r=remotes[id];if(now-r.t>5000){scene.remove(r.g);delete remotes[id];continue}r.g.position.x+=(r.tx-r.g.position.x)*Math.min(1,dt*10);r.g.position.y+=(r.ty-r.g.position.y)*Math.min(1,dt*10);r.g.position.z+=(r.tz-r.g.position.z)*Math.min(1,dt*10);r.g.rotation.y=r.rot}
if(a.player){const pl=a.player,m=Math.min(1,a.moving||0),s=Math.sin(now*.014)*.8*m,c=pl.children;if(c.length>=11){c[5].rotation.x=s;c[8].rotation.x=-s;c[6].position.z=.08+s*.18;c[9].position.z=.08-s*.18;c[7].rotation.x=-s;c[10].rotation.x=s}pl.children[0].rotation.z=Math.sin(now*.007)*.06*m;pl.rotation.z=0}
if(a.x!=null&&now-lastSend>100){lastSend=now;try{parent.postMessage({type:'bw2:position',x:a.x,y:a.y,z:a.z,rotation:a.rot||0},'*')}catch(e){}}};
BW.cam=cam=>{if(shakeT>0){shakeT-=.016;cam.position.x+=(Math.random()-.5)*shakeT*1.6;cam.position.y+=(Math.random()-.5)*shakeT*1.6}};
})();
