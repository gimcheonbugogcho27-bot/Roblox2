/* DOORS 업그레이드: 손전등 · 옷장 숨기 · RUSH · 상점 · 방 진행 */
(function(){
const C=window.__ctx;if(!C||C.MODE!=='doors'||!window.BW||!BW.S)return;C.own=true;
const {THREE,scene,camera,player,items}=C,$=id=>document.getElementById(id),up=BW.up;
const DEFS=[
{id:'light',name:'🔦 손전등',max:5,cost:l=>30*(l+1),desc:l=>'밝기·범위 +'+l*20+'%'},
{id:'boots',name:'👟 달리기',max:5,cost:l=>40*(l+1),desc:l=>'이동속도 +'+l*10+'%'},
{id:'hp',name:'❤️ 체력',max:5,cost:l=>35*(l+1),desc:l=>'최대 체력 '+(100+l*20)},
{id:'coin',name:'💰 수집 보너스',max:5,cost:l=>50*(l+1),desc:l=>'열쇠 코인 +'+l*30+'%'},
{id:'hide',name:'🚪 옷장 회복',max:3,cost:l=>60*(l+1),desc:l=>'숨는 동안 초당 +'+(4+l*4)+' 회복'}];
BW.setShop(DEFS);
let hp=100+up('hp')*20,keys=0,hidden=null,mcd=0,wt=0,wx=0,wz=-60,alive=0,rt=22+Math.random()*10,warn=0,rush=null,room=1,lastBeat=0;
/* 어두운 분위기 + 손전등 */
scene.children.forEach(o=>{if(o.isHemisphereLight)o.intensity=.3;if(o.isDirectionalLight)o.intensity=.25});
if(scene.fog){scene.fog.color.set(0x05060a);scene.fog.near=6;scene.fog.far=46}scene.background&&scene.background.set(0x05060a);
const fl=new THREE.SpotLight(0xfff0d0,2.4,40,.55,.45,1.2);scene.add(fl,fl.target);
/* 옷장 */
const LK=[-20,-36,-52,-68,-80].map((z,i)=>{const side=i%2?-1:1,g=new THREE.Group(),b=new THREE.Mesh(new THREE.BoxGeometry(1.3,2.7,1.2),new THREE.MeshLambertMaterial({color:0x4a3526}));b.position.y=1.35;g.add(b);
for(let k=0;k<5;k++){const s=new THREE.Mesh(new THREE.BoxGeometry(.9,.06,.05),new THREE.MeshBasicMaterial({color:0x120c08}));s.position.set(0,1.9+k*.12,.61);g.add(s)}
const h=new THREE.Mesh(new THREE.SphereGeometry(.07,8,6),new THREE.MeshBasicMaterial({color:0xd2a45f}));h.position.set(.4,1.3,.62);g.add(h);
g.position.set(side*3.1,0,z);g.rotation.y=side>0?-Math.PI/2:Math.PI/2;g.traverse(o=>{if(o.isMesh)o.castShadow=true});scene.add(g);return{x:side*3.1,z,side}});
/* RUSH 메시 */
function mkRush(){const g=new THREE.Group(),b=new THREE.Mesh(new THREE.BoxGeometry(2.6,2.6,5),new THREE.MeshBasicMaterial({color:0x020204}));b.position.y=1.5;g.add(b);
for(const x of[-.6,.6]){const e=new THREE.Mesh(new THREE.SphereGeometry(.28,10,8),new THREE.MeshBasicMaterial({color:0xffffff}));e.position.set(x,1.8,2.55);g.add(e)}
g.add(Object.assign(new THREE.PointLight(0xffffff,2.2,24),{position:new THREE.Vector3(0,1.5,3)}));scene.add(g);return g}
function hurt(v,kx,kz){hp-=v;BW.hp(hp/(100+up('hp')*20)*100);BW.flash('#ff1b3c');BW.sfx('hurt');BW.shake(.4);if(!hidden){C.px+=kx;C.pz+=kz}
 if(hp<=0){hp=100+up('hp')*20;BW.hp(100);C.px=0;C.pz=0;hidden=null;player.visible=true;const m=C.monster;if(m){m.position.x=0;m.position.z=-65}BW.banner('쓰러졌어요! 입구에서 다시 시작');keys=Math.max(0,keys-1)}}
function leave(){const l=hidden;hidden=null;player.visible=true;C.px=l.x-l.side*1.7;C.pz=l.z;BW.sfx('jump');BW.banner('옷장에서 나왔어요')}
function hide(l){hidden=l;player.visible=false;C.px=l.x;C.pz=l.z;BW.sfx('plant');BW.banner('🫥 숨었어요 — 행동 버튼으로 나오기')}
C.ext={
act(){if(hidden){leave();return}const px=C.px,pz=C.pz;
 const lk=LK.find(l=>Math.hypot(l.x-px,l.z-pz)<2.8);if(lk){hide(lk);return}
 const it=items.filter(o=>!o.done&&Math.hypot(o.x-px,o.z-pz)<3).sort((a,b)=>Math.hypot(a.x-px,a.z-pz)-Math.hypot(b.x-px,b.z-pz))[0];
 if(it){it.done=true;scene.remove(it.mesh);if(it.ring)scene.remove(it.ring);keys++;const c=Math.round(5*(1+.3*up('coin')));BW.coins(c);BW.sfx('pick');BW.burst(px,1.2,pz,0xf3d46a,28);BW.float('🔑 +'+c+'🪙',px,2.6,pz);BW.xp(10);BW.banner('열쇠 '+keys+'/5');return}
 if(Math.hypot(px,pz+88)<7){if(keys>=5){const r=100+Math.floor(alive);BW.coins(r);BW.xp(100);BW.best(10);BW.win('🚪 탈출 성공!','열쇠 '+keys+'개 · 보상 🪙 '+r+'\n상점에서 강화하고 다시 도전하세요 (🛒)')}else{BW.sfx('err');BW.banner('열쇠 '+keys+'/5 — 더 필요해요')}return}
 BW.sfx('err');BW.banner('열쇠나 옷장 가까이 가세요')},
frame(dt,now){alive+=dt;const lv=up('light');C.spd=8*(1+.1*up('boots'));const px=C.px,pz=C.pz,max=100+up('hp')*20;
 const fx=-Math.sin(C.yaw),fz=-Math.cos(C.yaw),fk=.88+.12*Math.sin(now*.013)*Math.sin(now*.0041);
 fl.position.set(px,2.1,pz);fl.target.position.set(px+fx*10,.8,pz+fz*10);fl.intensity=(2.1+.55*lv)*fk;fl.distance=34+5*lv;
 if(hidden){C.px=hidden.x;C.pz=hidden.z;if(hp<max){hp=Math.min(max,hp+dt*(4+4*up('hide')));BW.hp(hp/max*100)}}
 else{C.px=Math.max(-3.3,Math.min(3.3,C.px));C.pz=Math.max(-86,Math.min(5,C.pz))}
 room=Math.max(room,Math.min(10,Math.floor(-C.pz/8)+1));BW.best(room);
 /* 괴물 */
 const m=C.monster;if(m){const dx=C.px-m.position.x,dz=C.pz-m.position.z,d=Math.hypot(dx,dz)||1;mcd-=dt;
  if(!hidden&&d<30){const sp=3.1+Math.min(1.6,alive*.012);m.position.x+=dx/d*sp*dt;m.position.z+=dz/d*sp*dt;m.lookAt(C.px,1,C.pz)}
  else{wt-=dt;if(wt<0){wt=3;wx=(Math.random()-.5)*5;wz=Math.max(-84,Math.min(0,m.position.z+(Math.random()-.5)*30))}const ex=wx-m.position.x,ez=wz-m.position.z,ed=Math.hypot(ex,ez)||1;m.position.x+=ex/ed*2*dt;m.position.z+=ez/ed*2*dt}
  m.position.x=Math.max(-3.2,Math.min(3.2,m.position.x));m.position.y=1+Math.sin(now*.004)*.15;
  const dd=hidden?99:d;BW.danger(1-dd/16);if(dd<16&&now-lastBeat>300+dd*40){lastBeat=now;BW.sfx('beat')}
  if(!hidden&&d<2.4&&mcd<=0){mcd=1.1;hurt(25,-dx/d*3,-dz/d*3)}}
 /* RUSH */
 rt-=dt;if(rt<0&&!rush&&warn<=0){warn=3;BW.banner('⚠️ RUSH가 온다! 옷장에 숨으세요!');BW.sfx('beat')}
 if(warn>0){warn-=dt;BW.shake(.06);fl.intensity*=.5+.5*Math.random();if(warn<=0){rush={z:-94,g:mkRush(),hit:0,pass:0}}}
 if(rush){rush.z+=72*dt;rush.g.position.set(0,0,rush.z);if(Math.abs(rush.z-C.pz)<28)BW.shake(.12);
  if(!rush.hit&&Math.abs(rush.z-C.pz)<2.6&&!hidden){rush.hit=1;hurt(45,0,0)}
  if(!rush.pass&&rush.z>C.pz+3){rush.pass=1;if(!rush.hit){BW.coins(20);BW.xp(30);BW.float('RUSH 통과 +20🪙',C.px,2.8,C.pz,'#7dff9b')}}
  if(rush.z>12){scene.remove(rush.g);rush=null;rt=24+Math.random()*14}}
 if(hp>=max)BW.hp(100);
 const s=$('stats');if(s&&now-(this.t||0)>300){this.t=now;s.textContent='🔑 '+keys+'/5 · 🚪 방 '+room+'/10 · 🪙 '+Math.floor(BW.S.coins)}}};
})();
