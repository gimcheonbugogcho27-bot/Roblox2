/* Grow a Garden 업그레이드: 5종 작물 · 황금 변이 · 비/낮밤 · 스프링클러 · 밭 확장 · 상점 */
(function(){
const C=window.__ctx;if(!C||C.MODE!=='garden'||!window.BW||!BW.S)return;C.own=true;
const {THREE,scene,targetObjects:PL}=C,$=id=>document.getElementById(id),up=BW.up,S=BW.S;
const CR=[{n:'당근',e:'🥕',cost:2,t:20,v:7,c:0xff8a2a,lv:1},{n:'토마토',e:'🍅',cost:6,t:35,v:22,c:0xe8322b,lv:2},{n:'호박',e:'🎃',cost:15,t:55,v:60,c:0xff9d2e,lv:3},{n:'수박',e:'🍉',cost:40,t:80,v:180,c:0x2e9e4f,lv:5},{n:'무지개 베리',e:'🍇',cost:120,t:120,v:600,c:0x9b4dff,lv:8}];
const DEFS=[
{id:'water',name:'💧 물뿌리개',max:5,cost:l=>Math.round(25*Math.pow(l+1,1.4)),desc:l=>'물주기 성장 '+(10+l*4)+'%'},
{id:'spr',name:'🚿 스프링클러',max:5,cost:l=>Math.round(40*Math.pow(l+1,1.5)),desc:l=>'자동 성장 속도 +'+l*25+'%'},
{id:'plots',name:'🟫 밭 확장',max:4,cost:l=>Math.round(60*Math.pow(l+1,1.6)),desc:l=>'사용 가능한 밭 '+Math.min(25,9+4*l)+'칸'},
{id:'luck',name:'✨ 황금 확률',max:5,cost:l=>Math.round(50*Math.pow(l+1,1.4)),desc:l=>'황금 작물 '+(4+l*3)+'% (판매가 x6)'},
{id:'sell',name:'🏪 판매가',max:5,cost:l=>Math.round(45*Math.pow(l+1,1.5)),desc:l=>'수확 코인 +'+l*15+'%'}];
BW.setShop(DEFS,()=>plots());
if(S.total===0&&S.coins===0)BW.coins(12);
let sel=0,rain=0,rainCd=70,dayT=37.5,sprT=0;
/* 밭 잠금 */
const meshes=scene.children.filter(o=>o.isMesh&&Math.abs(o.position.y-.05)<1e-3&&o.geometry.parameters&&o.geometry.parameters.height===.15);
const order=PL.slice().sort((a,b)=>Math.hypot(a.x,a.z)-Math.hypot(b.x,b.z)||a.x-b.x);
PL.forEach(p=>{p.m=meshes.find(m=>Math.abs(m.position.x-p.x)<.01&&Math.abs(m.position.z-p.z)<.01);p.pl=null});
function plots(){const n=9+4*up('plots');PL.forEach(p=>{p.open=order.indexOf(p)<n;if(p.m)p.m.material.color.setHex(p.open?0x76502f:0x2e2218)})}plots();
/* 작물 모델 */
function build(type,gold){const G=new THREE.Group(),M=(c,e)=>new THREE.MeshStandardMaterial({color:c,roughness:.55,emissive:e||0,emissiveIntensity:e?.55:0});
const sp=new THREE.Group(),st=new THREE.Mesh(new THREE.CylinderGeometry(.04,.06,.5,6),M(0x3fa34d));st.position.y=.25;sp.add(st);
for(const s of[-1,1]){const l=new THREE.Mesh(new THREE.ConeGeometry(.14,.4,5),M(0x58c86b));l.position.set(s*.16,.5,0);l.rotation.z=-s*1.1;sp.add(l)}
const fr=new THREE.Group(),col=gold?0xffd24d:CR[type].c,fm=M(col,gold?0xffa500:0),add=(g,m,y,sc)=>{const o=new THREE.Mesh(g,m);o.position.y=y;if(sc)o.scale.set(...sc);o.castShadow=true;fr.add(o);return o};
if(type===0){const c=add(new THREE.ConeGeometry(.28,.9,10),fm,.45);c.rotation.x=Math.PI;for(let i=0;i<3;i++){const l=new THREE.Mesh(new THREE.ConeGeometry(.08,.5,5),M(0x3fa34d));l.position.set((i-1)*.12,1.05,0);l.rotation.z=(i-1)*.4;fr.add(l)}}
else if(type===1){add(new THREE.SphereGeometry(.42,14,12),fm,.5);add(new THREE.CylinderGeometry(.2,.2,.05,8),M(0x2e8b3d),.92)}
else if(type===2){add(new THREE.SphereGeometry(.5,14,12),fm,.45,[1.15,.85,1.15]);add(new THREE.CylinderGeometry(.06,.09,.28,6),M(0x6b4a2a),.95)}
else if(type===3){add(new THREE.SphereGeometry(.55,16,12),fm,.5,[1.25,.95,.95]);add(new THREE.SphereGeometry(.56,16,12),M(gold?0xffe27a:0x1d6b36),.5,[.3,.96,.96])}
else{for(let i=0;i<6;i++){const o=add(new THREE.SphereGeometry(.2,10,8),fm,.45+(i%3)*.22);o.position.x=(i<3?-.18:.18)+((i*37)%10-5)*.02;o.position.z=((i*17)%10-5)*.02}add(new THREE.CylinderGeometry(.03,.03,.5,5),M(0x3fa34d),1.1)}
G.add(sp,fr);G.userData={sp,fr};G.position.y=.12;return G}
/* 씨앗 선택 바 */
const bar=document.createElement('div');bar.style.cssText='position:fixed;left:10px;top:100px;z-index:5;display:flex;flex-direction:column;gap:6px';document.body.appendChild(bar);
const btns=CR.map((c,i)=>{const b=document.createElement('button');b.style.cssText='min-width:96px;padding:6px 9px;border-radius:12px;border:2px solid #fff4;background:#000b;color:#fff;font-weight:800;font-size:12px;text-align:left';b.onclick=()=>{if(S.lv<c.lv){BW.sfx('err');BW.banner('🔒 레벨 '+c.lv+'에 해금');return}sel=i;BW.sfx('pick');ui()};bar.appendChild(b);return b});
function ui(){btns.forEach((b,i)=>{const c=CR[i],lock=S.lv<c.lv;b.innerHTML=c.e+' '+c.n+'<br><small>'+(lock?'🔒 Lv.'+c.lv:'🪙 '+c.cost+' · '+c.t+'초')+'</small>';b.style.opacity=lock?.45:1;b.style.borderColor=i===sel?'#ffd24d':'#fff4';b.style.background=i===sel?'#5b3a00cc':'#000b'})}ui();
/* 비 */
const RN=260,rg=new THREE.BufferGeometry(),rp=new Float32Array(RN*3);for(let i=0;i<RN;i++){rp[i*3]=(Math.random()-.5)*40;rp[i*3+1]=Math.random()*18;rp[i*3+2]=(Math.random()-.5)*40}rg.setAttribute('position',new THREE.BufferAttribute(rp,3));
const rainP=new THREE.Points(rg,new THREE.PointsMaterial({color:0xa8d8ff,size:.14,transparent:true,opacity:.8,depthWrite:false}));rainP.visible=false;rainP.frustumCulled=false;scene.add(rainP);
const lights=scene.children.filter(o=>o.isDirectionalLight||o.isHemisphereLight).map(l=>({l,b:l.intensity}));
const NT=new THREE.Color(0x070a22),NB=new THREE.Color(0x1a2550),DT=new THREE.Color(0x58b8ff),DB=new THREE.Color(0xdff4ff),WM=new THREE.Color(0xff9a6a),ta=new THREE.Color(),tb=new THREE.Color();
const near=()=>PL.filter(p=>p.open&&Math.hypot(p.x-C.px,p.z-C.pz)<3.2).sort((a,b)=>Math.hypot(a.x-C.px,a.z-C.pz)-Math.hypot(b.x-C.px,b.z-C.pz))[0];
C.ext={
act(){if(C.pz>14.5){BW.shop();return}const p=near();if(!p){BW.sfx('err');BW.banner('열린 밭 가까이 가세요 (상점은 맨 아래 가판대)');return}
 const px=C.px,pz=C.pz;
 if(!p.pl){const c=CR[sel];if(S.lv<c.lv){BW.sfx('err');BW.banner('🔒 레벨 '+c.lv+' 필요');return}
  if(!PL.some(q=>q.pl)&&S.coins<CR[0].cost)BW.coins(CR[0].cost-S.coins);
  if(S.coins<c.cost){BW.sfx('err');BW.banner('코인이 부족해요 🪙'+c.cost);return}
  BW.coins(-c.cost);const gold=Math.random()<.04+.03*up('luck'),g=build(sel,gold);g.position.set(p.x,.12,p.z);scene.add(g);p.pl={type:sel,g:0,gold,cd:0,grp:g};BW.sfx('plant');BW.burst(p.x,.3,p.z,0x8b5a2b,14);BW.banner(c.e+' 심었어요!'+(gold?' ✨황금 씨앗!':''));return}
 const q=p.pl;
 if(q.g<1){if(q.cd>0){BW.sfx('err');BW.banner('아직 촉촉해요 ('+Math.ceil(q.cd)+'s)');return}q.g=Math.min(1,q.g+.10+.04*up('water'));q.cd=3;BW.sfx('water');BW.burst(p.x,1.3,p.z,0x66ccff,22);BW.banner('💧 물을 줬어요 '+Math.floor(q.g*100)+'%');return}
 const c=CR[q.type],val=Math.round(c.v*(q.gold?6:1)*(1+.15*up('sell')));BW.coins(val);BW.xp(Math.ceil(val/3)+3);BW.sfx('win');BW.burst(p.x,1.2,p.z,q.gold?0xffd24d:c.c,40);BW.float('+'+val+' 🪙',px,2.6,pz,q.gold?'#ffd24d':'#7dff9b');if(q.gold){BW.shake(.15);BW.banner('✨ 황금 '+c.n+' 수확!')}
 scene.remove(q.grp);p.pl=null},
frame(dt,now){const px=C.px,pz=C.pz;
 /* 성장 */
 const rate=(rain>0?2.2:1)*(1+.25*up('spr'));
 PL.forEach(p=>{const q=p.pl;if(!q)return;const c=CR[q.type];q.cd=Math.max(0,q.cd-dt);q.g=Math.min(1,q.g+dt/c.t*rate);
  const u=q.grp.userData,g=q.g;u.sp.visible=g<.6;u.sp.scale.setScalar(.45+Math.min(1,g/.4)*.9);u.fr.visible=g>=.35;u.fr.scale.setScalar(.3+.7*Math.min(1,(g-.35)/.65));
  q.grp.position.y=.12+(g>=1?Math.abs(Math.sin(now*.005+p.x))*.12:0);q.grp.rotation.y+=g>=1?dt*1.2:0;
  if(g>=1&&!q.rdy){q.rdy=1;BW.burst(p.x,1.1,p.z,q.gold?0xffd24d:0xffffff,18);BW.sfx('plant')}});
 sprT-=dt;if(up('spr')>0&&sprT<0){sprT=1.6-.2*up('spr');const a=PL.filter(p=>p.pl&&p.pl.g<1);if(a.length){const p=a[Math.floor(Math.random()*a.length)];BW.burst(p.x,1.6,p.z,0x66ccff,8)}}
 /* 비 */
 rainCd-=dt;if(rain>0){rain-=dt;if(rain<=0){rainP.visible=false;BW.banner('☀️ 비가 그쳤어요')}}else if(rainCd<0){rain=25;rainCd=85+Math.random()*40;rainP.visible=true;BW.banner('🌧️ 비가 와요! 성장 2배');BW.sfx('water')}
 if(rain>0){rainP.position.set(px,0,pz);const a=rg.attributes.position.array;for(let i=0;i<RN;i++){a[i*3+1]-=26*dt;if(a[i*3+1]<0)a[i*3+1]=18}rg.attributes.position.needsUpdate=true}
 /* 낮밤 */
 dayT+=dt;const k=(Math.sin(dayT/150*6.283)+1)/2,mid=1-Math.abs(2*k-1);
 ta.copy(NT).lerp(DT,k);tb.copy(NB).lerp(DB,k);tb.lerp(WM,mid*.45);if(rain>0){ta.multiplyScalar(.7);tb.multiplyScalar(.75)}
 const u=BW.dome.material.uniforms;u.a.value.copy(ta);u.b.value.copy(tb);scene.background&&scene.background.copy(tb);scene.fog&&scene.fog.color.copy(tb);
 lights.forEach(o=>{o.l.intensity=o.b*(.28+.72*k)*(rain>0?.8:1)});
 C.px=Math.max(-19,Math.min(19,C.px));
 const s=$('stats');if(s&&now-(this.t||0)>300){this.t=now;const hh=Math.floor(((dayT/150)%1)*24);s.textContent='🪙 '+Math.floor(S.coins)+' · '+CR[sel].e+' '+CR[sel].n+' · '+(rain>0?'🌧️':k>.5?'☀️':'🌙')+' · 🌱 '+PL.filter(p=>p.pl).length+'/'+Math.min(25,9+4*up('plots'));if(!this.u||now-this.u>1500){this.u=now;ui()}}}};
})();
